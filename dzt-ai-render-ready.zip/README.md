# DZ T AI

موقع دردشة عربي RTL بواجهة متجاوبة، مع سجل محادثات محفوظ محلياً في متصفح المستخدم. يتصل الخادم بواجهة Perplexity المحددة في `config.py`.

## التشغيل محلياً

```bash
python -m venv .venv
. .venv/bin/activate  # على Windows: .venv\Scripts\activate
pip install -r requirements.txt

# عيّن القيم السرية في بيئة التشغيل قبل التشغيل الفعلي
export PPLX_TOKEN='ضع_التوكن_هنا'
export PPLX_USER_ID='معرّف_المستخدم'
export PPLX_DEVICE_ID='معرّف_الجهاز'
export DZT_ACCESS_USERNAME='admin'
export DZT_ACCESS_PASSWORD='كلمة_مرور_قوية'
python server.py
```

افتح `http://127.0.0.1:8080`. سيطلب المتصفح اسم المستخدم وكلمة المرور. في وضع الاختبار المحلي فقط يمكن تشغيل `DZT_MOCK=1` مع كلمة مرور الموقع لتجربة الواجهة دون API.

## النشر على Render

أنشئ **Web Service** من مستودع Git، ثم استخدم:

- Runtime: `Python`
- Build Command: `pip install -r requirements.txt`
- Start Command: `python server.py`
- Health Check Path: `/api/health`

أضف المتغيرات السرية من صفحة Environment في Render، ولا تضعها داخل Git:

| المتغير | المطلوب |
|---|---|
| `PPLX_TOKEN` | رمز API/جلسة Perplexity الفعّال |
| `PPLX_USER_ID` | معرّف مستخدم Perplexity |
| `PPLX_DEVICE_ID` | معرّف جهاز Perplexity |
| `DZT_ACCESS_USERNAME` | اسم دخول الموقع (مثلاً `admin`) |
| `DZT_ACCESS_PASSWORD` | كلمة مرور قوية وفريدة |
| `RATE_LIMIT_PER_MIN` | اختياري، الافتراضي 30 طلباً لكل IP بالدقيقة |
| `TRUST_PROXY` | اجعله `1` خلف Render proxy |

يُستخدم HTTPS على Render. الخادم يرفض بدء التشغيل الفعلي عند غياب `PPLX_TOKEN` أو كلمة مرور الموقع.

## الأمان

- لا توجد رموز API أو كلمات مرور مضمّنة في ملفات المصدر.
- كل صفحات الموقع وواجهات API محمية بمصادقة HTTP Basic؛ مسار الفحص الصحي `/api/health` فقط متاح دون تسجيل دخول.
- لا تُسجّل الرسائل أو أجسام طلبات API في السجلات.
- حدّ الطلبات مطبّق لكل عنوان IP، وحجم طلب JSON محدود.
- المحادثات تبقى في `localStorage` لدى المتصفح، بينما حالة متابعة المحادثة تُرسل إلى الخادم مع كل رسالة.

## الملفات

| الملف | الوظيفة |
|---|---|
| `config.py` | إعدادات API وقائمة النماذج؛ الأسرار تُقرأ من متغيرات البيئة |
| `server.py` | خادم HTTP وواجهات الدردشة والحذف وفحص الصحة |
| `static/` | الواجهة والتصميم والمنطق الأمامي |
| `requirements.txt` | اعتماديات Python |
