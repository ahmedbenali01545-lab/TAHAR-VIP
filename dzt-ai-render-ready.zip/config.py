# -*- coding: utf-8 -*-
"""إعدادات DZ T AI — نفس القيم الموجودة في main.py (منسوخة حرفياً)."""
import os

# Secrets are supplied through the hosting provider's environment variables.
# Never place API tokens or site passwords in this source file.
PPLX_TOKEN = os.getenv("PPLX_TOKEN", "").strip()
ACCESS_USERNAME = os.getenv("DZT_ACCESS_USERNAME", "admin").strip() or "admin"
ACCESS_PASSWORD = os.getenv("DZT_ACCESS_PASSWORD", "")

USER_ID = os.getenv("PPLX_USER_ID", "").strip()
DEVICE_ID = os.getenv("PPLX_DEVICE_ID", "").strip()
TIMEZONE = "Africa/Algiers"
LANGUAGE = "en-DZ"

BASE = "https://www.perplexity.ai"
APP_VERSION = "2.103.0"
USER_AGENT = ("Ask/2.103.0/260673 (Android; Version 12; "
              "OPPO CPH2473/CPH2473_11_A.99) SDK 31")

SUPPORTED_BLOCKS = [
    "answer_modes", "finance_widgets", "inline_assets", "inline_entity_cards",
    "inline_images", "media_items", "navigation_results", "place_widgets",
    "placeholder_cards", "search_result_widgets", "maps_preview", "inline_claims",
    "workflow_steps", "workflow_answer", "workflow_thoughts_v1", "workflow_widgets",
    "in_context_suggestions", "pending_followups", "background_agents",
    "ask_user_question_empty_options", "diff_blocks", "answer_tabs",
    "asset_diff_assets", "accessory_blocks", "news_widgets",
]

PREFER_CURL = os.getenv("PREFER_CURL", "0") == "1"
USE_ANDROID_PARAMS = os.getenv("USE_ANDROID_PARAMS", "1") != "0"

# ===== النماذج المعروضة في الموقع (فقط هذه الأربعة) =====
MODELS = [
    {"key": "gpt6_1_sol_thinking",    "label": "GPT-6.1 Sol Thinking",       "provider": "OpenAI",    "mode": "copilot"},
    {"key": "claude55sonnetthinking", "label": "Claude Sonnet 5.5 Thinking", "provider": "Anthropic", "mode": "copilot"},
    {"key": "gemini4argonthinking",   "label": "Gemini 4 Argon Thinking",    "provider": "Google",    "mode": "copilot"},
    {"key": "grok47thinking",         "label": "Grok 4.7 Thinking",          "provider": "xAI",       "mode": "copilot"},
]
DEFAULT_MODEL = MODELS[0]["key"]
