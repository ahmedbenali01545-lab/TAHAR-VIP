extends CharacterBody3D
## اللاعب: حركة + أنيميشن + كاميرا من الشخص الثالث

const WALK_SPEED := 3.2
const GRAVITY := 22.0
const ACCEL := 14.0
const TURN_SPEED := 10.0
const STRIDE_SPEED := 1.2   # سرعة (م/ث) التي صُمّم عليها أنيميشن walk بسرعة 1.0
const LOOK_SENS := 0.0045
const CAM_DISTANCE := 4.5

var touch = null
var limit := 100.0
var yaw := 0.0
var pitch := -0.25

var model: Node3D
var anim: AnimationPlayer
var anim_idle := ""
var anim_walk := ""
var pivot: Node3D


func setup(touch_controls, world_limit: float) -> void:
	touch = touch_controls
	limit = world_limit


func _ready() -> void:
	floor_snap_length = 0.6
	floor_max_angle = deg_to_rad(55.0)

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0.0, 0.9, 0.0)
	add_child(cs)

	_load_model()
	_build_camera()


func _load_model() -> void:
	var path := "res://assets/player.glb"
	if ResourceLoader.exists(path):
		var scene: PackedScene = load(path)
		model = scene.instantiate()
		add_child(model)
		anim = model.find_child("AnimationPlayer", true, false) as AnimationPlayer
	else:
		push_warning("player.glb not found, using capsule")
		model = Node3D.new()
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.35
		cm.height = 1.8
		mi.mesh = cm
		mi.position = Vector3(0.0, 0.9, 0.0)
		model.add_child(mi)
		add_child(model)

	if anim:
		print("Player animations: ", anim.get_animation_list())
		for n in anim.get_animation_list():
			var low := String(n).to_lower()
			if low.contains("walk"):
				anim_walk = String(n)
			elif low.contains("idle"):
				anim_idle = String(n)
		for n in [anim_idle, anim_walk]:
			if n != "":
				anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
		_play(anim_idle, 1.0)


func _build_camera() -> void:
	pivot = Node3D.new()
	pivot.position = Vector3(0.0, 1.55, 0.0)
	add_child(pivot)

	var arm := SpringArm3D.new()
	arm.spring_length = CAM_DISTANCE
	arm.margin = 0.25
	arm.add_excluded_object(get_rid())
	pivot.add_child(arm)

	var cam := Camera3D.new()
	cam.fov = 70.0
	cam.far = 260.0
	arm.add_child(cam)
	cam.make_current()


func _play(anim_name: String, speed: float) -> void:
	if anim == null or anim_name == "":
		return
	anim.speed_scale = speed
	if anim.current_animation != anim_name:
		anim.play(anim_name, 0.2)


func _physics_process(delta: float) -> void:
	# ---- الكاميرا ----
	var look := Vector2.ZERO
	if touch != null:
		look = touch.look_delta
		touch.look_delta = Vector2.ZERO
	yaw -= look.x * LOOK_SENS
	pitch = clampf(pitch - look.y * LOOK_SENS, -1.2, 0.35)
	pivot.rotation = Vector3(pitch, yaw, 0.0)

	# ---- إدخال الحركة (لمس + كيبورد للتجربة على الحاسوب) ----
	var inp := Vector2.ZERO
	if touch != null:
		inp = touch.move
	var kx := int(Input.is_key_pressed(KEY_D)) - int(Input.is_key_pressed(KEY_A))
	var ky := int(Input.is_key_pressed(KEY_S)) - int(Input.is_key_pressed(KEY_W))
	if kx != 0 or ky != 0:
		inp = Vector2(kx, ky).normalized()
	if inp.length() > 1.0:
		inp = inp.normalized()

	# ---- الحركة بالنسبة للكاميرا ----
	var dir := Basis(Vector3.UP, yaw) * Vector3(inp.x, 0.0, inp.y)
	var target := Vector2(dir.x, dir.z) * WALK_SPEED
	var hv := Vector2(velocity.x, velocity.z).move_toward(target, ACCEL * delta)
	velocity.x = hv.x
	velocity.z = hv.y
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	position.x = clampf(position.x, -limit, limit)
	position.z = clampf(position.z, -limit, limit)

	# ---- اتجاه الشخصية والأنيميشن ----
	var spd := hv.length()
	if spd > 0.2 and model:
		var want := atan2(-hv.x, -hv.y)
		model.rotation.y = lerp_angle(model.rotation.y, want, TURN_SPEED * delta)
	if spd > 0.15:
		_play(anim_walk, clampf(spd / STRIDE_SPEED, 0.5, 2.8))
	else:
		_play(anim_idle, 1.0)
