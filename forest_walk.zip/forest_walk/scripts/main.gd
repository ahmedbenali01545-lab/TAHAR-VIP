extends Node3D
## Forest Walk - يبني العالم بالكامل بالكود:
## سماء + تضاريس + غابة (MultiMesh) + لاعب + أزرار اللمس

# ---------------- إعدادات الجودة (عدّلها حسب أداء الجهاز) ----------------
const WORLD_SIZE := 220.0
const HALF := WORLD_SIZE * 0.5
const TERRAIN_CELLS := 110
const SHADOWS := true
const GRASS_DENSITY := 0.26   # مجموعات عشب لكل متر مربع (قلّلها لو الجهاز ضعيف)
const SPAWN_CLEAR := 7.0

var noise := FastNoiseLite.new()
var color_noise := FastNoiseLite.new()
var density_noise := FastNoiseLite.new()
var rng := RandomNumberGenerator.new()
var colliders := StaticBody3D.new()
var occupied: Array = []   # عناصر Vector3(x, z, نصف_القطر)

var wind_grass: Shader = load("res://shaders/wind_grass.gdshader")
var wind_solid: Shader = load("res://shaders/wind_solid.gdshader")

var player
var touch
var fps_label: Label


func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	rng.seed = 20261023
	_setup_noise()
	_build_environment()
	_build_terrain()
	add_child(colliders)
	for t in _types():
		_scatter(t)
	_build_hud()
	_spawn_player()


func _process(_delta: float) -> void:
	if fps_label:
		fps_label.text = "FPS %d" % Engine.get_frames_per_second()


# ---------------- الضوضاء والارتفاع ----------------
func _setup_noise() -> void:
	noise.seed = 1337
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.010
	noise.fractal_octaves = 3

	color_noise.seed = 77
	color_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	color_noise.frequency = 0.05

	density_noise.seed = 9
	density_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	density_noise.frequency = 0.03


func height_at(x: float, z: float) -> float:
	var h := noise.get_noise_2d(x, z) * 5.0
	var d := Vector2(x, z).length()
	h *= smoothstep(4.0, 20.0, d)   # أرض مستوية حول نقطة البداية
	return h


# ---------------- السماء والإضاءة ----------------
func _build_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.20, 0.44, 0.82)
	sky_mat.sky_horizon_color = Color(0.68, 0.80, 0.90)
	sky_mat.ground_horizon_color = Color(0.68, 0.80, 0.90)
	sky_mat.ground_bottom_color = Color(0.25, 0.32, 0.28)
	sky_mat.sun_angle_max = 30.0
	sky_mat.sun_curve = 0.15

	var sky := Sky.new()
	sky.sky_material = sky_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.66, 0.78, 0.86)
	env.fog_density = 0.012
	env.fog_sky_affect = 0.3

	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48.0, -35.0, 0.0)
	sun.light_color = Color(1.0, 0.94, 0.82)
	sun.light_energy = 1.15
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


# ---------------- التضاريس ----------------
func _ground_color(x: float, z: float) -> Color:
	var n := color_noise.get_noise_2d(x, z) * 0.5 + 0.5
	var c := Color(0.16, 0.34, 0.09).lerp(Color(0.30, 0.48, 0.14), n)
	var dirt := color_noise.get_noise_2d(x * 0.6 + 300.0, z * 0.6)
	var k := clampf((dirt - 0.35) * 2.5, 0.0, 1.0) * 0.8
	return c.lerp(Color(0.33, 0.24, 0.14), k)


func _build_terrain() -> void:
	var n := TERRAIN_CELLS + 1
	var step := WORLD_SIZE / TERRAIN_CELLS
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	for j in n:
		for i in n:
			var x := -HALF + i * step
			var z := -HALF + j * step
			var y := height_at(x, z)
			var nx := height_at(x - step, z) - height_at(x + step, z)
			var nz := height_at(x, z - step) - height_at(x, z + step)
			st.set_normal(Vector3(nx, 2.0 * step, nz).normalized())
			st.set_color(_ground_color(x, z))
			st.set_uv(Vector2(float(i), float(j)))
			st.add_vertex(Vector3(x, y, z))

	for j in TERRAIN_CELLS:
		for i in TERRAIN_CELLS:
			var a := j * n + i
			var b := a + 1
			var c := a + n
			var d := c + 1
			st.add_index(a)
			st.add_index(b)
			st.add_index(c)
			st.add_index(b)
			st.add_index(d)
			st.add_index(c)

	var mesh := st.commit()
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 1.0
	mesh.surface_set_material(0, mat)

	var body := StaticBody3D.new()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	cs.shape = mesh.create_trimesh_shape()
	body.add_child(cs)
	add_child(body)


# ---------------- أنواع العناصر في الغابة ----------------
func _types() -> Array:
	return [
		{"name": "pine_tree", "count": 230, "smin": 0.85, "smax": 1.4,
		 "radius": 0.5, "cheight": 5.0, "collide": true, "solid": true,
		 "clear": SPAWN_CLEAR, "chunk": 74.0, "vis": 0.0,
		 "sway": 0.35, "href": 9.5, "skip": ["Bark"]},
		{"name": "oak_tree", "count": 70, "smin": 0.85, "smax": 1.25,
		 "radius": 0.8, "cheight": 5.0, "collide": true, "solid": true,
		 "clear": SPAWN_CLEAR, "chunk": 74.0, "vis": 0.0,
		 "sway": 0.22, "href": 7.5, "skip": ["Bark"]},
		{"name": "rock_1", "count": 20, "smin": 0.8, "smax": 1.5,
		 "radius": 0.9, "cheight": 0.85, "collide": true, "solid": true,
		 "clear": 5.0, "chunk": 55.0, "vis": 110.0, "sink": -0.08},
		{"name": "rock_2", "count": 26, "smin": 0.8, "smax": 1.5,
		 "radius": 0.6, "cheight": 0.6, "collide": true, "solid": true,
		 "clear": 5.0, "chunk": 55.0, "vis": 110.0, "sink": -0.08},
		{"name": "rock_3", "count": 16, "smin": 0.8, "smax": 1.5,
		 "radius": 1.05, "cheight": 0.7, "collide": true, "solid": true,
		 "clear": 5.0, "chunk": 55.0, "vis": 110.0, "sink": -0.08},
		{"name": "log", "count": 14, "smin": 0.85, "smax": 1.2,
		 "radius": 1.6, "box": Vector3(3.1, 0.75, 0.9), "collide": true, "solid": true,
		 "clear": 5.0, "chunk": 55.0, "vis": 110.0, "sink": -0.05},
		{"name": "bush", "count": 150, "smin": 0.8, "smax": 1.5,
		 "radius": 0.4, "collide": false, "solid": false,
		 "clear": 3.5, "chunk": 55.0, "vis": 100.0,
		 "sway": 0.06, "href": 1.0, "skip": ["Twig", "Berry"]},
		{"name": "grass", "count": int(WORLD_SIZE * WORLD_SIZE * GRASS_DENSITY),
		 "smin": 0.8, "smax": 1.5, "xz": 1.5, "y": 0.8, "patchy": true,
		 "chunk": 16.0, "vis": 32.0, "shadow": false,
		 "sway": 0.22, "href": 0.85, "double_sided": true, "skip": []},
	]


func _collect_meshes(n: Node, xf: Transform3D, out: Array) -> void:
	var t := xf
	if n is Node3D:
		t = xf * (n as Node3D).transform
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		out.append({"mesh": (n as MeshInstance3D).mesh, "xf": t})
	for c in n.get_children():
		_collect_meshes(c, t, out)


func _load_mesh(asset: String) -> Dictionary:
	var path := "res://assets/%s.glb" % asset
	if not ResourceLoader.exists(path):
		push_warning("Missing asset: " + path)
		return {}
	var scene: PackedScene = load(path)
	var inst := scene.instantiate()
	var out: Array = []
	_collect_meshes(inst, Transform3D.IDENTITY, out)
	inst.free()
	if out.is_empty():
		push_warning("No mesh found in: " + path)
		return {}
	return out[0]


func _make_wind_mesh(src: Mesh, strength: float, href: float, skip: Array, double_sided: bool) -> Mesh:
	var m := src.duplicate() as Mesh
	var shader: Shader = wind_grass if double_sided else wind_solid
	for i in m.get_surface_count():
		var bm := m.surface_get_material(i) as BaseMaterial3D
		if bm == null:
			continue
		var nm := String(bm.resource_name)
		var skipit := false
		for s in skip:
			if nm.begins_with(String(s)):
				skipit = true
		if skipit:
			continue
		var sm := ShaderMaterial.new()
		sm.shader = shader
		sm.set_shader_parameter("albedo", bm.albedo_color)
		sm.set_shader_parameter("strength", strength)
		sm.set_shader_parameter("height_ref", href)
		m.surface_set_material(i, sm)
	return m


func _blocked(x: float, z: float, r: float) -> bool:
	for o in occupied:
		var ov: Vector3 = o
		var dx := x - ov.x
		var dz := z - ov.y
		var need := r + ov.z + 0.35
		if dx * dx + dz * dz < need * need:
			return true
	return false


func _scatter(t: Dictionary) -> void:
	var info := _load_mesh(t["name"])
	if info.is_empty():
		return
	var mesh: Mesh = info["mesh"]
	var base_xf: Transform3D = info["xf"]

	var sway: float = t.get("sway", 0.0)
	if sway > 0.0:
		mesh = _make_wind_mesh(mesh, sway, float(t.get("href", 1.0)),
				t.get("skip", []), bool(t.get("double_sided", false)))

	var count: int = t["count"]
	var radius: float = t.get("radius", 0.0)
	var solid: bool = t.get("solid", false)
	var clear: float = t.get("clear", 0.0)
	var patchy: bool = t.get("patchy", false)
	var xz_mul: float = t.get("xz", 1.0)
	var y_mul: float = t.get("y", 1.0)
	var sink: float = t.get("sink", 0.0)

	# ---- اختيار المواضع ----
	var items: Array = []
	var tries := 0
	while items.size() < count and tries < count * 15:
		tries += 1
		var x := rng.randf_range(-HALF + 4.0, HALF - 4.0)
		var z := rng.randf_range(-HALF + 4.0, HALF - 4.0)
		if Vector2(x, z).length() < clear:
			continue
		if patchy and density_noise.get_noise_2d(x, z) < -0.15:
			continue
		var s := rng.randf_range(float(t["smin"]), float(t["smax"]))
		var r := radius * s
		if radius > 0.0 and _blocked(x, z, r):
			continue
		items.append({
			"pos": Vector3(x, height_at(x, z) + sink, z),
			"rot": rng.randf() * TAU,
			"sxz": s * xz_mul,
			"sy": s * y_mul,
		})
		if solid:
			occupied.append(Vector3(x, z, r))

	# ---- تقسيم إلى كتل (chunks) لتسريع الرسم والإخفاء حسب المسافة ----
	var chunk: float = t["chunk"]
	var buckets: Dictionary = {}
	for it in items:
		var p: Vector3 = it["pos"]
		var key := Vector2i(int(floor((p.x + HALF) / chunk)), int(floor((p.z + HALF) / chunk)))
		if not buckets.has(key):
			buckets[key] = []
		buckets[key].append(it)

	var vis: float = t.get("vis", 0.0)
	var cast_shadow: bool = t.get("shadow", true)

	for key in buckets:
		var arr: Array = buckets[key]
		var origin := Vector3((key.x + 0.5) * chunk - HALF, 0.0, (key.y + 0.5) * chunk - HALF)
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = arr.size()
		for i in arr.size():
			var it: Dictionary = arr[i]
			var p: Vector3 = it["pos"]
			var sxz: float = it["sxz"]
			var sy: float = it["sy"]
			var b := Basis(Vector3.UP, float(it["rot"])).scaled(Vector3(sxz, sy, sxz))
			mm.set_instance_transform(i, Transform3D(b, p - origin) * base_xf)
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.position = origin
		if vis > 0.0:
			mmi.visibility_range_end = vis
		if not cast_shadow:
			mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mmi)

	# ---- التصادم ----
	if t.get("collide", false):
		for it in items:
			_add_collider(t, it)

	print("Placed ", items.size(), " x ", t["name"])


func _add_collider(t: Dictionary, it: Dictionary) -> void:
	var p: Vector3 = it["pos"]
	var sxz: float = it["sxz"]
	var sy: float = it["sy"]
	var cs := CollisionShape3D.new()
	if t.has("box"):
		var bx := BoxShape3D.new()
		var sz: Vector3 = t["box"]
		bx.size = sz * sxz
		cs.shape = bx
		cs.transform = Transform3D(Basis(Vector3.UP, float(it["rot"])), p + Vector3(0.0, bx.size.y * 0.5, 0.0))
	else:
		var cy := CylinderShape3D.new()
		cy.radius = float(t["radius"]) * sxz
		cy.height = float(t["cheight"]) * sy
		cs.shape = cy
		cs.position = p + Vector3(0.0, cy.height * 0.5, 0.0)
	colliders.add_child(cs)


# ---------------- الواجهة واللاعب ----------------
func _build_hud() -> void:
	var hud := CanvasLayer.new()
	add_child(hud)

	touch = load("res://scripts/touch_controls.gd").new()
	hud.add_child(touch)

	fps_label = Label.new()
	fps_label.position = Vector2(16.0, 10.0)
	fps_label.add_theme_font_size_override("font_size", 22)
	fps_label.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	hud.add_child(fps_label)


func _spawn_player() -> void:
	var script: GDScript = load("res://scripts/player.gd")
	player = script.new()
	player.position = Vector3(0.0, height_at(0.0, 0.0) + 0.3, 0.0)
	player.call("setup", touch, HALF - 3.0)
	add_child(player)
