# Forest Walk (Godot 4.7.2)

لعبة 3D: شخصية تتجول في غابة. عصا حركة يسار، سحب يمين للنظر.
على الحاسوب: WASD + سحب الماوس.

## البناء
ارفع المشروع إلى GitHub (فرع main) وسيُبنى الـ APK تلقائيًا من تبويب Actions
(Artifacts → forest-walk-apk).
