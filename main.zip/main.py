#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Perplexity Telegram Chat Bot
----------------------------
* حط توكن تلجرام في TELEGRAM_TOKEN تحت (أو متغير بيئة TELEGRAM_TOKEN) وشغّل:  python main.py
* كل التوكنات/المعرفات المأخوذة من الطلبات موجودة تحت (PPLX_TOKEN, USER_ID, DEVICE_ID).
* اللوجس تظهر في الترمنال وتتحفظ في bot.log
    DEBUG=1  -> يطبع كل طلب وكل رد سرفر (الافتراضي)
    DEBUG=0  -> لوجس خفيفة فقط
    LOG_BODY_LIMIT=4000 (0 = بدون قص)   LOG_EVENT_LIMIT=1200
"""
import asyncio
import functools
import html
import json
import logging
import os
import re
import sys
import time
import uuid
from collections import Counter
from logging.handlers import RotatingFileHandler
from pathlib import Path

import httpx
from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ChatAction, ParseMode
from telegram.error import BadRequest
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, filters)

# =====================================================================
#                              الإعدادات
# =====================================================================
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "8792248963:AAGxXA-CLT2iL6d1vkgObCVENwqkY1MLRvI")

PPLX_TOKEN = os.getenv(
    "PPLX_TOKEN",
    "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..gff7LYuMkxP9dWsZ.E6PmzA2mZclKIcRoBdXK9m3GwtYLEqGJD-okFauYpt8uyfxryHJvbftSiOqas7pNJS5XrtJ7gAlxUHzgy3TgxrlhjtzKGaxqNLb9-VGDizAeHCbWFlSr0UTvh_l-npa43iwT7-YOtbUnEGOrbGomVhp7Q1GxbqLUL5HJg54qUP_4wb8UbgavO2BiEoU4qCmZ_Bdw0faNuqyVpB3FGLt7U9WXch90nMJO78wUAbT0XwYJkRoD6s-MO5eJjsQyNzGBMd8s_kxP-IwzY0tqNd44RMuCPJSiuCe-L1bpl4uy67BIzHgwE1RINd_IHIU.aQfEDjvowkssvDbhpO4Szg",
)
USER_ID = os.getenv("PPLX_USER_ID", "cafe4078-055a-45f8-9022-be3c9b8bf580")
DEVICE_ID = os.getenv("PPLX_DEVICE_ID", "fb870518568fe0c0")
TIMEZONE = "Africa/Algiers"
LANGUAGE = "en-DZ"

BASE = "https://www.perplexity.ai"
APP_VERSION = "2.103.0"
USER_AGENT = ("Ask/2.103.0/260673 (Android; Version 12; "
              "OPPO CPH2473/CPH2473_11_A.99) SDK 31")

DEFAULT_MODEL = os.getenv("DEFAULT_MODEL", "claude55sonnetthinking")

# فارغ = الكل مسموح. مثال: ALLOWED_USERS="123456789 987654321"  (أمر /id يعطيك رقمك)
ALLOWED = {int(x) for x in os.getenv("ALLOWED_USERS", "").replace(",", " ").split()
           if x.strip().lstrip("-").isdigit()}

DEBUG = os.getenv("DEBUG", "1") != "0"
LOG_BODY_LIMIT = int(os.getenv("LOG_BODY_LIMIT", "4000"))
LOG_EVENT_LIMIT = int(os.getenv("LOG_EVENT_LIMIT", "1200"))
PREFER_CURL = os.getenv("PREFER_CURL", "0") == "1"   # 1 = ابدأ بـ curl_cffi بدل httpx
USE_ANDROID_PARAMS = os.getenv("USE_ANDROID_PARAMS", "1") != "0"

STATE_FILE = Path(os.getenv("STATE_FILE", "state.json"))

SUPPORTED_BLOCKS = [
    "answer_modes", "finance_widgets", "inline_assets", "inline_entity_cards",
    "inline_images", "media_items", "navigation_results", "place_widgets",
    "placeholder_cards", "search_result_widgets", "maps_preview", "inline_claims",
    "workflow_steps", "workflow_answer", "workflow_thoughts_v1", "workflow_widgets",
    "in_context_suggestions", "pending_followups", "background_agents",
    "ask_user_question_empty_options", "diff_blocks", "answer_tabs",
    "asset_diff_assets", "accessory_blocks", "news_widgets",
]

# =====================================================================
#                              اللوجس
# =====================================================================
log = logging.getLogger("pplxbot")


def setup_logging():
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s", "%H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    fh = RotatingFileHandler("bot.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(sh)
    root.addHandler(fh)
    for noisy in ("httpx", "httpcore", "hpack", "telegram", "h2", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    log.setLevel(logging.DEBUG if DEBUG else logging.INFO)


def clip(obj, n=None):
    n = LOG_BODY_LIMIT if n is None else n
    s = obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False)
    if not n or len(s) <= n:
        return s
    return s[:n] + f"... [+{len(s) - n} chars]"


def mask_headers(h):
    out = {}
    for k, v in h.items():
        if k.lower() == "authorization" and len(v) > 30:
            v = v[:18] + "…" + v[-6:]
        out[k] = v
    return out


# =====================================================================
#                     الاتصال بـ Perplexity (HTTP)
# =====================================================================
def hdrs(sse=False):
    h = {
        "authorization": f"Bearer {PPLX_TOKEN}",
        "user-agent": USER_AGENT,
        "x-app-version": APP_VERSION,
        "x-client-version": APP_VERSION,
        "x-client-name": "Perplexity-Android",
        "x-client-env": "prod",
        "x-app-apiclient": "android",
        "x-app-apiversion": "2.17",
        "accept-language": LANGUAGE,
        "x-device-id": f"android:{DEVICE_ID}",
        "content-type": "application/json; charset=utf-8",
    }
    if sse:
        h["accept"] = "text/event-stream"
    return h


def _t_httpx(method, url, headers, body):
    with httpx.Client(http2=True, timeout=httpx.Timeout(30.0, read=300.0)) as c:
        r = c.request(method, url, headers=headers, json=body)
        return r.status_code, dict(r.headers), r.content.decode("utf-8", "replace")


def _t_curl(method, url, headers, body):
    from curl_cffi import requests as creq  # ImportError لو غير مثبت
    r = creq.request(method, url, headers=headers, json=body,
                     impersonate="chrome", timeout=300)
    return r.status_code, dict(r.headers), r.content.decode("utf-8", "replace")


def _is_cf_block(status, headers, text):
    low = (text or "")[:3000].lower()
    h = {k.lower(): v for k, v in headers.items()}
    return status in (403, 429, 503) and (
        "just a moment" in low or "attention required" in low
        or "cf-mitigated" in h or "cloudflare" in low)


def call(method, url, body=None, sse=False):
    """يرجع (status, headers, text). يجرب httpx ثم curl_cffi لو انحظر من Cloudflare."""
    order = ["curl", "httpx"] if PREFER_CURL else ["httpx", "curl"]
    last = (0, {}, "")
    for name in order:
        headers = hdrs(sse)
        log.debug(">>> [%s] %s %s\n    headers=%s\n    body=%s",
                  name, method, url, mask_headers(headers),
                  clip(body) if body is not None else "-")
        t0 = time.time()
        try:
            fn = _t_httpx if name == "httpx" else _t_curl
            status, rh, text = fn(method, url, headers, body)
        except ImportError as e:
            log.warning("transport %s غير متوفر: %s", name, e)
            continue
        except Exception as e:  # noqa
            log.error("transport %s فشل: %r", name, e)
            last = (0, {}, repr(e))
            continue
        log.debug("<<< [%s] HTTP %s (%.2fs) headers=%s",
                  name, status, time.time() - t0, clip(rh, 1500))
        last = (status, rh, text)
        if _is_cf_block(status, rh, text):
            log.warning("Cloudflare حظر الطلب عبر %s -> نجرب الناقل الثاني", name)
            continue
        return last
    return last


def parse_sse(text):
    events, ev, data = [], None, []

    def flush():
        nonlocal ev, data
        if data:
            payload = "\n".join(data)
            try:
                obj = json.loads(payload)
            except json.JSONDecodeError:
                obj = payload
            events.append((ev, obj))
        ev, data = None, []

    for raw in text.splitlines():
        if raw.startswith("event:"):
            ev = raw[6:].strip()
        elif raw.startswith("data:"):
            data.append(raw[5:].lstrip())
        elif not raw.strip():
            flush()
    flush()
    return events


# =====================================================================
#                     استخراج النص من رد السرفر
# =====================================================================
def extract_text(msg):
    if not isinstance(msg, dict):
        return ""
    parts = []
    for b in msg.get("blocks") or []:
        wb = b.get("workflow_block")
        if wb:
            for step in wb.get("steps") or []:
                for it in step.get("items") or []:
                    tp = (it.get("payload") or {}).get("text_payload")
                    if tp and it.get("variant", "answer") == "answer":
                        t = tp.get("text") or "".join(tp.get("chunks") or [])
                        if t:
                            parts.append(t)
    if parts:
        return "\n\n".join(parts).strip()
    for b in msg.get("blocks") or []:
        mb = b.get("markdown_block")
        if mb:
            t = mb.get("answer") or "".join(mb.get("chunks") or [])
            if t:
                parts.append(t)
    if parts:
        return "\n\n".join(parts).strip()
    for k in ("answer", "text"):
        if isinstance(msg.get(k), str) and msg[k].strip():
            return msg[k].strip()
    return ""


MEDIA_URL_RE = re.compile(r'https?://[^\s"\\<>]+?\.(?:png|jpe?g|webp|gif|mp4|mov|webm)(?:\?[^\s"\\<>]*)?', re.I)


def build_params(query, model, mode, thread):
    followup = bool(thread.get("last_backend"))
    params = {
        "source": "android",
        "version": "2.17",
        "frontend_uuid": str(uuid.uuid4()),
        "frontend_context_uuid": thread["fe_ctx"],
        "user_nextauth_id": USER_ID,
        "android_device_id": DEVICE_ID,
        "mode": mode,
        "is_related_query": False,
        "is_voice_to_voice": False,
        "timezone": TIMEZONE,
        "language": LANGUAGE,
        "query_source": "followup" if followup else ("computer" if mode == "asi" else "home"),
        "is_incognito": False,
        "use_schematized_api": True,
        "send_back_text_in_streaming_api": False,
        "supported_block_use_cases": SUPPORTED_BLOCKS,
        "disable_widgets": ["shopping"],
        "sources": ["web"],
        "model_preference": model,
    }
    if USE_ANDROID_PARAMS:
        params["android_assistant_params"] = {
            "supports_android_connectors": False,
            "enabled_android_connectors": {},
            "apps": "[Perplexity, Telegram, Chrome]",
            "client_capabilities": [],
            "version": "2.4",
            "client_type": "thread",
            "camera_input": False,
            "drawing_input": False,
            "is_default_assistant": False,
            "can_read_screen_context": False,
            "is_samsung_preload": False,
            "is_multi_window": False,
            "is_24_hour_format": True,
            "default_sms_app": "com.android.mms",
        }
    if followup:
        params["last_backend_uuid"] = thread["last_backend"]
        if thread.get("rw_token"):
            params["read_write_token"] = thread["rw_token"]
    return params


def ask_once(query, model, mode, thread):
    res = {"ok": False, "text": "", "display_model": None, "urls": [],
           "error": None, "status": 0}
    body = {"query_str": query, "params": build_params(query, model, mode, thread)}
    status, rh, text = call("POST", f"{BASE}/rest/sse/perplexity_ask", body, sse=True)
    res["status"] = status
    if status != 200:
        res["error"] = f"HTTP {status}: {clip(text, 500)}"
        log.error("ask فشل: %s", res["error"])
        return res

    events = parse_sse(text)
    log.debug("استلمنا %d event من السرفر", len(events))
    msgs = []
    for i, (ev, obj) in enumerate(events):
        if isinstance(obj, dict):
            log.debug("  [%d] event=%s status=%s final=%s display_model=%s text_completed=%s\n      %s",
                      i, ev, obj.get("status"), obj.get("final"), obj.get("display_model"),
                      obj.get("text_completed"),
                      clip(obj, LOG_BODY_LIMIT if i == len(events) - 2 else LOG_EVENT_LIMIT))
            if ev in (None, "message"):
                msgs.append(obj)
            if ev == "error":
                res["error"] = clip(obj, 500)
        else:
            log.debug("  [%d] event=%s data=%s", i, ev, clip(str(obj), 300))
    if not msgs:
        res["error"] = res["error"] or "ما وصل أي رد من السرفر"
        log.error("%s | raw=%s", res["error"], clip(text, 1500))
        return res

    final = next((m for m in reversed(msgs) if m.get("final_sse_message")), msgs[-1])
    answer = ""
    for cand in [final] + list(reversed(msgs)):
        answer = extract_text(cand)
        if answer:
            break
    res["text"] = answer
    res["display_model"] = final.get("display_model")
    res["urls"] = list(dict.fromkeys(MEDIA_URL_RE.findall(json.dumps(final, ensure_ascii=False))))[:6]

    if not answer and not res["urls"]:
        res["error"] = (f"الرد فارغ (status={final.get('status')}). "
                        "شوف الـ final event في اللوجس.")
        log.error("%s", res["error"])
        return res

    res["ok"] = True
    thread["last_backend"] = final.get("backend_uuid") or thread.get("last_backend")
    thread["context_uuid"] = final.get("context_uuid") or thread.get("context_uuid")
    thread["rw_token"] = final.get("read_write_token") or thread.get("rw_token")
    thread["n"] = thread.get("n", 0) + 1
    log.info("رد ناجح | model=%s display=%s chars=%d ctx=%s",
             model, res["display_model"], len(answer), thread.get("context_uuid"))
    return res


def delete_thread_sync(context_uuid, rw_token):
    body = {"context_uuids": [context_uuid], "entry_uuids": [], "read_write_token": rw_token}
    status, rh, text = call("DELETE", f"{BASE}/rest/thread", body)
    ok = status in (200, 202, 204)
    log.info("حذف محادثة %s -> HTTP %s %s", context_uuid, status, clip(text, 300))
    return ok, status, text


# =====================================================================
#                          سجل النماذج
# =====================================================================
# key|الاسم|المزود|النمط    (يتحدث تلقائياً من /rest/models/config/v2 عند التشغيل)
STATIC_MODELS = """
turbo|Best (Turbo)|PERPLEXITY|search
pplx_pro|Best|PERPLEXITY|search
pplx_pro_upgraded|Pro|PERPLEXITY|search
experimental|Sonar 2|PERPLEXITY|search
claudefable52|Claude Fable 5.2|ANTHROPIC|search
claudefable52thinking|Claude Fable 5.2 Thinking|ANTHROPIC|search
claudefable51|Claude Fable 5.1|ANTHROPIC|search
claudefable51thinking|Claude Fable 5.1 Thinking|ANTHROPIC|search
claude55opus|Claude Opus 5.5|ANTHROPIC|search
claude55opusthinking|Claude Opus 5.5 Thinking|ANTHROPIC|search
claude55sonnet|Claude Sonnet 5.5|ANTHROPIC|search
claude55sonnetthinking|Claude Sonnet 5.5 Thinking|ANTHROPIC|search
claude50sonnet|Claude Sonnet 5|ANTHROPIC|search
claude50sonnetthinking|Claude Sonnet 5 Thinking|ANTHROPIC|search
claude55haiku|Claude Haiku 5.5|ANTHROPIC|search
claude55haikuthinking|Claude Haiku 5.5 Thinking|ANTHROPIC|search
claude48opus|Claude Opus 4.8|ANTHROPIC|search
claude48opusthinking|Claude Opus 4.8 Thinking|ANTHROPIC|search
claude47opus|Claude Opus 4.7|ANTHROPIC|search
claude47opusthinking|Claude Opus 4.7 Thinking|ANTHROPIC|search
claude46opus|Claude Opus 4.6|ANTHROPIC|search
claude46opusthinking|Claude Opus 4.6 Thinking|ANTHROPIC|search
claude45opus|Claude Opus 4.5|ANTHROPIC|search
claude45opusthinking|Claude Opus 4.5 Thinking|ANTHROPIC|search
claude41opus|Claude Opus 4.1|ANTHROPIC|search
claude41opusthinking|Claude Opus 4.1 Thinking|ANTHROPIC|search
claude40opus|Claude Opus 4.0|ANTHROPIC|search
claude40opusthinking|Claude Opus 4.0 Thinking|ANTHROPIC|search
claude46sonnet|Claude Sonnet 4.6|ANTHROPIC|search
claude46sonnetthinking|Claude Sonnet 4.6 Thinking|ANTHROPIC|search
claude45sonnet|Claude Sonnet 4.5|ANTHROPIC|search
claude45sonnetthinking|Claude Sonnet 4.5 Thinking|ANTHROPIC|search
claude2|Claude Sonnet 4.0|ANTHROPIC|search
claude40sonnetthinking|Claude Sonnet 4.0 Thinking|ANTHROPIC|search
claude37sonnetthinking|Claude Sonnet 4.0 Thinking (3.7)|ANTHROPIC|search
claude45haiku|Claude Haiku 4.5|ANTHROPIC|search
claude45haikuthinking|Claude Haiku 4.5 Thinking|ANTHROPIC|search
claudecode|Claude Code|ANTHROPIC|search
gpt6_astra|GPT-6 Astra|OPENAI|search
gpt6_astra_thinking|GPT-6 Astra Thinking|OPENAI|search
gpt6_1_sol|GPT-6.1 Sol|OPENAI|search
gpt6_1_sol_thinking|GPT-6.1 Sol Thinking|OPENAI|search
gpt6_sol|GPT-6 Sol|OPENAI|search
gpt6_sol_thinking|GPT-6 Sol Thinking|OPENAI|search
gpt56_sol|GPT-5.6 Sol|OPENAI|search
gpt56_sol_thinking|GPT-5.6 Sol Thinking|OPENAI|search
gpt56_terra|GPT-5.6 Terra|OPENAI|search
gpt56_terra_thinking|GPT-5.6 Terra Thinking|OPENAI|search
gpt55|GPT-5.5|OPENAI|search
gpt55_thinking|GPT-5.5 Thinking|OPENAI|search
gpt54|GPT-5.4|OPENAI|search
gpt54_thinking|GPT-5.4 Thinking|OPENAI|search
gpt53codex|GPT-5.3 Codex|OPENAI|search
gpt52|GPT-5.2|OPENAI|search
gpt52_thinking|GPT-5.2 Thinking|OPENAI|search
gpt52_pro|GPT-5.2 Pro|OPENAI|search
gpt51|GPT-5.1|OPENAI|search
gpt51_thinking|GPT-5.1 Thinking|OPENAI|search
gpt51_low_thinking|GPT-5.1 Low Thinking|OPENAI|search
gpt5|GPT-5|OPENAI|search
gpt5_thinking|GPT-5 Thinking|OPENAI|search
gpt5_pro|GPT-5 Pro|OPENAI|search
gpt5_mini|GPT-5 Mini|OPENAI|search
gpt5_nano|GPT-5 Nano|OPENAI|search
gpt41|GPT-4.1|OPENAI|search
gpt4o|GPT-4o|OPENAI|search
o3pro|o3-pro|OPENAI|search
chatgpt_tools|ChatGPT Tools|OPENAI|search
codex|Codex|OPENAI|search
gemini4argon|Gemini 4 Argon|GOOGLE|search
gemini4argonthinking|Gemini 4 Argon Thinking|GOOGLE|search
gemini38flash|Gemini 3.8 Flash|GOOGLE|search
gemini38flashthinking|Gemini 3.8 Flash Thinking|GOOGLE|search
gemini37flash|Gemini 3.7 Flash|GOOGLE|search
gemini37flashthinking|Gemini 3.7 Flash Thinking|GOOGLE|search
gemini35flash|Gemini 3.5 Flash|GOOGLE|search
gemini35flash_medium|Gemini 3.5 Flash Medium Thinking|GOOGLE|search
gemini35flash_high|Gemini 3.5 Flash Thinking|GOOGLE|search
gemini31pro_low|Gemini 3.1 Pro|GOOGLE|search
gemini31pro_high|Gemini 3.1 Pro Thinking|GOOGLE|search
gemini30pro|Gemini 3 Pro|GOOGLE|search
gemini30flash|Gemini 3 Flash|GOOGLE|search
gemini30flash_high|Gemini 3 Flash Thinking|GOOGLE|search
gemini25pro|Gemini 2.5 Pro|GOOGLE|search
grok47|Grok 4.7|XAI|search
grok47thinking|Grok 4.7 Thinking|XAI|search
grok46low|Grok 4.6|XAI|search
grok46medium|Grok 4.6 Thinking|XAI|search
grok45low|Grok 4.5|XAI|search
grok45medium|Grok 4.5 Thinking|XAI|search
grok41reasoning|Grok 4.1 (reasoning)|XAI|search
grok41nonreasoning|Grok 4.1|XAI|search
grok4|Grok 4 (reasoning)|XAI|search
grok4nonthinking|Grok 4|XAI|search
grok|Grok 3 Beta|XAI|search
kimik3thinking|Kimi K3|MOONSHOT_AI|search
kimik26instant|Kimi K2.6|MOONSHOT_AI|search
kimik26thinking|Kimi K2.6 Thinking|MOONSHOT_AI|search
kimik25thinking|Kimi K2.5 Thinking|MOONSHOT_AI|search
kimik2thinking|Kimi K2|MOONSHOT_AI|search
glm_5_3_thinking|GLM-5.3|ZAI|search
glm_5_2|GLM-5.2|ZAI|search
nv_nemotron_3_ultra|Nemotron 3 Ultra|NVIDIA|search
nv_nemotron_3_5_super|Nemotron 3.5 Super VL|NVIDIA|search
nanobananapro|Nano Banana Pro|GOOGLE|search
nanobanana2|Nano Banana 2|GOOGLE|search
veo31|Veo 3.1|GOOGLE|search
veo31fast|Veo 3.1 Fast|GOOGLE|search
sora2|Sora 2|OPENAI|search
sora2pro|Sora 2 Pro|OPENAI|search
pplx_asi|Computer|ANTHROPIC|asi
pplx_asi_fable_5|Claude Fable 5.2|ANTHROPIC|asi
pplx_asi_opus|Claude Opus 5.5|ANTHROPIC|asi
pplx_asi_opus_fast|Claude Opus 5.5|ANTHROPIC|asi
pplx_asi_sonnet|Claude Sonnet 5.5|ANTHROPIC|asi
pplx_asi_sonnet_thinking|Claude Sonnet 5 Thinking|ANTHROPIC|asi
pplx_asi_opus_thinking|Claude Opus 4.8 Thinking|ANTHROPIC|asi
pplx_asi_astra|GPT-6 Astra|OPENAI|asi
pplx_asi_astra_fast|GPT-6 Astra Fast|OPENAI|asi
pplx_asi_astra_ultrafast|GPT-6 Astra Ultrafast|OPENAI|asi
pplx_asi_gpt_6_sol|GPT-6 Sol|OPENAI|asi
pplx_asi_gpt_6_sol_fast|GPT-6 Sol Fast|OPENAI|asi
pplx_asi_gpt_6_1_sol|GPT-6.1 Sol|OPENAI|asi
pplx_asi_gpt_6_1_sol_fast|GPT-6.1 Sol Fast|OPENAI|asi
pplx_asi_gpt_6_1_sol_ultrafast|GPT-6.1 Sol Ultrafast|OPENAI|asi
pplx_asi_gpt_56_sol|GPT-5.6 Sol|OPENAI|asi
pplx_asi_gpt_56_sol_fast|GPT-5.6 Sol Fast|OPENAI|asi
pplx_asi_gpt_55|GPT-5.5|OPENAI|asi
pplx_asi_gpt54|GPT-5.4|OPENAI|asi
pplx_asi_gemini_4_argon|Gemini 4 Argon|GOOGLE|asi
pplx_asi_gemini_3_8_flash|Gemini 3.8 Flash|GOOGLE|asi
pplx_asi_glm|Computer-1|PERPLEXITY|asi
pplx_asi_glm_pt_0728|Preview (GLM 5.2 PT-based)|PERPLEXITY|asi
pplx_asi_kimi_k3|Kimi K3|MOONSHOT_AI|asi
pplx_asi_kimi|Kimi K2.5|FIREWORKS|asi
pplx_asi_grok|Grok 4.7|XAI|asi
pplx_asi_grok_46|Grok 4.6|XAI|asi
pplx_asi_grok_45|Grok 4.5|XAI|asi
pplx_asi_deepseek_v4_pro|DeepSeek V4 Pro|DEEPSEEK|asi
pplx_asi_qwen|Qwen 3.6 Plus|FIREWORKS|asi
"""

MEDIA_KEYS = {"nanobananapro", "nanobanana2", "sora2", "sora2pro", "veo31", "veo31fast"}
PROVIDER_GROUP = {
    "ANTHROPIC": "Anthropic", "OPENAI": "OpenAI", "GOOGLE": "Google", "XAI": "xAI",
    "MOONSHOT_AI": "Moonshot", "ZAI": "Z.ai", "NVIDIA": "NVIDIA",
    "PERPLEXITY": "Perplexity", "DEEPSEEK": "DeepSeek", "FIREWORKS": "Fireworks",
}
GROUP_ORDER = ["Anthropic", "OpenAI", "Google", "xAI", "Moonshot", "Z.ai", "NVIDIA",
               "Perplexity", "DeepSeek", "Fireworks", "Computer 🖥", "Media 🎨"]
MODE_MAP = {"search": "copilot", "asi": "asi"}

MODELS = {}          # key -> {base, label, group, mode}
GROUPS = []          # أسماء المجموعات بالترتيب
GROUP_MODELS = {}    # group -> [keys]


def add_model(key, label, provider, mode):
    if mode not in MODE_MAP:
        return
    provider = provider or "PERPLEXITY"
    if mode == "asi":
        group = "Computer 🖥"
        low = label.lower()
        if key.endswith("_ultrafast") and "fast" not in low:
            label += " (Ultrafast)"
        elif key.endswith("_fast") and "fast" not in low:
            label += " (Fast)"
    elif key in MEDIA_KEYS:
        group = "Media 🎨"
    else:
        group = PROVIDER_GROUP.get(provider, provider.title())
    MODELS[key] = {"base": label, "label": label, "group": group, "mode": MODE_MAP[mode]}


def load_static_models():
    for line in STATIC_MODELS.strip().splitlines():
        if line.strip() and not line.startswith("#"):
            key, label, provider, mode = [p.strip() for p in line.split("|")]
            add_model(key, label, provider, mode)


def load_dynamic_models():
    """يجلب القائمة الحقيقية من نفس endpoint التطبيق ويحدّث الأسماء ويضيف أي نموذج جديد."""
    try:
        status, _, text = call("GET", f"{BASE}/rest/models/config/v2")
        if status != 200:
            log.warning("models/config/v2 رجع HTTP %s -> نستعمل القائمة المدمجة. body=%s",
                        status, clip(text, 400))
            return
        cfg = json.loads(text)
        n = 0
        for key, v in (cfg.get("models") or {}).items():
            if v.get("replaced_by") or v.get("provider") == "SONAR":
                continue
            add_model(key, v.get("label") or key, v.get("provider"), v.get("mode"))
            n += 1
        log.info("تم جلب %d نموذج من السيرفر", n)
    except Exception as e:  # noqa
        log.warning("فشل جلب النماذج الديناميكية: %r -> نستعمل القائمة المدمجة", e)


def finalize_registry():
    by_group = {}
    for k, v in MODELS.items():
        by_group.setdefault(v["group"], []).append(k)
    for g, keys in by_group.items():
        cnt = Counter(MODELS[k]["base"] for k in keys)
        for k in keys:
            b = MODELS[k]["base"]
            MODELS[k]["label"] = b if cnt[b] == 1 else f"{b} [{k}]"
    GROUPS.clear()
    GROUP_MODELS.clear()
    for g in GROUP_ORDER + [g for g in by_group if g not in GROUP_ORDER]:
        if g in by_group:
            GROUPS.append(g)
            GROUP_MODELS[g] = by_group[g]
    log.info("إجمالي النماذج: %d في %d مجموعة", len(MODELS), len(GROUPS))


# =====================================================================
#                            حالة المستخدمين
# =====================================================================
STATE = {}
LOCKS = {}


def load_state():
    global STATE
    try:
        if STATE_FILE.exists():
            STATE = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as e:  # noqa
        log.warning("تعذر قراءة state.json: %r", e)
        STATE = {}


def save_state():
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(STATE, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(STATE_FILE)
    except Exception as e:  # noqa
        log.warning("تعذر حفظ state.json: %r", e)


def U(uid):
    s = STATE.setdefault(str(uid), {})
    s.setdefault("model", DEFAULT_MODEL)
    s.setdefault("thread", None)
    s.setdefault("threads", [])
    return s


def new_thread():
    return {"fe_ctx": str(uuid.uuid4()), "last_backend": None,
            "context_uuid": None, "rw_token": None, "n": 0}


def model_info(key):
    return MODELS.get(key) or {"label": key, "mode": "copilot", "group": "?"}


def ask_with_retry(st, query, model, mode):
    thread = st.get("thread") or new_thread()
    st["thread"] = thread
    res = ask_once(query, model, mode, thread)
    if not res["ok"] and thread.get("last_backend"):
        log.warning("المتابعة فشلت -> نعيد المحاولة كمحادثة جديدة")
        thread = new_thread()
        st["thread"] = thread
        res = ask_once(query, model, mode, thread)
        res["note"] = "⚠️ فشلت المتابعة فبدأت محادثة جديدة."
    if res["ok"] and thread.get("context_uuid"):
        lst = st["threads"]
        for t in lst:
            if t["context_uuid"] == thread["context_uuid"]:
                t["rw_token"] = thread["rw_token"]
                break
        else:
            lst.append({"context_uuid": thread["context_uuid"], "rw_token": thread["rw_token"]})
    return res


# =====================================================================
#                           تنسيق رسائل تلجرام
# =====================================================================
def _inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`\n]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t, flags=re.S)
    t = re.sub(r"^#{1,6}\s*(.+)$", r"<b>\1</b>", t, flags=re.M)
    return t


def md_to_html(text):
    out, pos = [], 0
    for m in re.finditer(r"```[^\n`]*\n?(.*?)```", text, re.S):
        out.append(_inline(text[pos:m.start()]))
        out.append("<pre>" + html.escape(m.group(1).strip("\n"), quote=False) + "</pre>")
        pos = m.end()
    out.append(_inline(text[pos:]))
    return "".join(out)


def split_text(t, limit=3500):
    chunks = []
    while len(t) > limit:
        cut = t.rfind("\n\n", 0, limit)
        if cut < limit * 0.5:
            cut = t.rfind("\n", 0, limit)
        if cut < limit * 0.5:
            cut = limit
        chunks.append(t[:cut])
        t = t[cut:].lstrip("\n")
    if t.strip():
        chunks.append(t)
    return chunks or ["(فارغ)"]


async def send_long(placeholder, chat, text):
    first = True
    for ch in split_text(text):
        for mode in ("html", "plain"):
            try:
                body, pm = (md_to_html(ch), ParseMode.HTML) if mode == "html" else (ch, None)
                if first and placeholder is not None:
                    await placeholder.edit_text(body, parse_mode=pm)
                else:
                    await chat.send_message(body, parse_mode=pm)
                break
            except BadRequest as e:
                log.warning("فشل إرسال (%s): %s", mode, e)
        first = False


# =====================================================================
#                          لوحات الأزرار
# =====================================================================
PAGE = 12


def kb_groups():
    rows, row = [], []
    for i, g in enumerate(GROUPS):
        row.append(InlineKeyboardButton(f"{g} ({len(GROUP_MODELS[g])})", callback_data=f"g|{i}|0"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return InlineKeyboardMarkup(rows)


def kb_models(gi, page, cur):
    g = GROUPS[gi]
    keys = GROUP_MODELS[g]
    total = max(1, (len(keys) + PAGE - 1) // PAGE)
    page = max(0, min(page, total - 1))
    rows = []
    for k in keys[page * PAGE:(page + 1) * PAGE]:
        label = ("✅ " if k == cur else "") + MODELS[k]["label"][:42]
        rows.append([InlineKeyboardButton(label, callback_data=f"m|{k}|{gi}|{page}")])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"g|{gi}|{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total}", callback_data="x"))
    if page < total - 1:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"g|{gi}|{page + 1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton("🔙 المزودين", callback_data="home")])
    return InlineKeyboardMarkup(rows)


def cur_line(key):
    return f"النموذج الحالي: {model_info(key)['label']}\n({key})"


# =====================================================================
#                              الأوامر
# =====================================================================
def guarded(fn):
    @functools.wraps(fn)
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if ALLOWED and (not user or user.id not in ALLOWED):
            log.warning("مستخدم غير مسموح: %s", user.id if user else None)
            if update.callback_query:
                await update.callback_query.answer("⛔ غير مسموح", show_alert=True)
            elif update.message:
                await update.message.reply_text(f"⛔ غير مسموح. ID: {user.id if user else '?'}")
            return
        try:
            await fn(update, ctx)
        except Exception:
            log.exception("خطأ في المعالج %s", fn.__name__)
            try:
                target = update.effective_message
                if target:
                    await target.reply_text("❌ صار خطأ داخلي، شوف اللوجس في الترمنال.")
            except Exception:  # noqa
                pass
    return wrapper


@guarded
async def cmd_start(update, ctx):
    st = U(update.effective_user.id)
    await update.message.reply_text(
        "أهلاً! ابعث أي رسالة وأرد عليك بالنموذج المختار.\n\n"
        f"{cur_line(st['model'])}\n\n"
        "/models — اختيار النموذج (أزرار)\n"
        "/model <اسم> — اختيار بالاسم أو الـ key\n"
        "/current — الحالة الحالية\n"
        "/new — محادثة جديدة\n"
        "/delete — حذف المحادثة الحالية من السيرفر\n"
        "/deleteall — حذف كل محادثات البوت من السيرفر\n"
        "/id — رقم حسابك")


@guarded
async def cmd_id(update, ctx):
    await update.message.reply_text(f"ID: {update.effective_user.id}")


@guarded
async def cmd_models(update, ctx):
    st = U(update.effective_user.id)
    await update.message.reply_text(cur_line(st["model"]) + "\n\nاختر المزود:",
                                    reply_markup=kb_groups())


@guarded
async def cmd_model(update, ctx):
    st = U(update.effective_user.id)
    arg = " ".join(ctx.args).strip().lower()
    if not arg:
        await update.message.reply_text(cur_line(st["model"]) + "\n\nاستعمل /models أو /model <اسم>")
        return
    if arg in MODELS:
        st["model"] = arg
        save_state()
        await update.message.reply_text("✅ " + cur_line(arg))
        return
    hits = [k for k, v in MODELS.items()
            if arg in k.lower() or arg in v["label"].lower()]
    exact = [k for k in hits if MODELS[k]["base"].lower() == arg]
    if len(exact) == 1:
        hits = exact
    if len(hits) == 1:
        st["model"] = hits[0]
        save_state()
        await update.message.reply_text("✅ " + cur_line(hits[0]))
    elif not hits:
        await update.message.reply_text("ما لقيت نموذج بهذا الاسم. جرب /models")
    else:
        rows = [[InlineKeyboardButton(MODELS[k]["label"][:42], callback_data=f"m|{k}|-1|0")]
                for k in hits[:20]]
        await update.message.reply_text(f"لقيت {len(hits)} نتيجة، اختر:",
                                        reply_markup=InlineKeyboardMarkup(rows))


@guarded
async def cmd_current(update, ctx):
    st = U(update.effective_user.id)
    th = st.get("thread") or {}
    await update.message.reply_text(
        f"{cur_line(st['model'])}\n"
        f"النمط: {model_info(st['model'])['mode']}\n"
        f"رسائل في المحادثة: {th.get('n', 0)}\n"
        f"context: {th.get('context_uuid') or '-'}\n"
        f"محادثات محفوظة على السيرفر: {len(st['threads'])}")


@guarded
async def cmd_new(update, ctx):
    st = U(update.effective_user.id)
    st["thread"] = None
    save_state()
    await update.message.reply_text("🆕 بدأنا محادثة جديدة (القديمة بقيت على السيرفر، /delete تحذف الحالية).")


@guarded
async def cmd_delete(update, ctx):
    st = U(update.effective_user.id)
    th = st.get("thread")
    if not th or not th.get("context_uuid") or not th.get("rw_token"):
        st["thread"] = None
        save_state()
        await update.message.reply_text("ما في محادثة محفوظة على السيرفر. بدأت محادثة جديدة.")
        return
    ok, status, text = await asyncio.to_thread(delete_thread_sync, th["context_uuid"], th["rw_token"])
    if ok:
        st["threads"] = [t for t in st["threads"] if t["context_uuid"] != th["context_uuid"]]
        st["thread"] = None
        save_state()
        await update.message.reply_text("🗑 تم حذف المحادثة من السيرفر.")
    else:
        await update.message.reply_text(f"❌ فشل الحذف (HTTP {status}):\n{clip(text, 300)}")


@guarded
async def cmd_deleteall(update, ctx):
    st = U(update.effective_user.id)
    items = list(st["threads"])
    cur = st.get("thread") or {}
    if cur.get("context_uuid") and all(t["context_uuid"] != cur["context_uuid"] for t in items) and cur.get("rw_token"):
        items.append({"context_uuid": cur["context_uuid"], "rw_token": cur["rw_token"]})
    if not items:
        await update.message.reply_text("ما في محادثات محفوظة.")
        return
    done = failed = 0
    for t in items:
        ok, _, _ = await asyncio.to_thread(delete_thread_sync, t["context_uuid"], t["rw_token"])
        if ok:
            done += 1
            st["threads"] = [x for x in st["threads"] if x["context_uuid"] != t["context_uuid"]]
        else:
            failed += 1
    st["thread"] = None
    save_state()
    await update.message.reply_text(f"🗑 انحذف {done} | فشل {failed}")


@guarded
async def on_callback(update, ctx):
    q = update.callback_query
    data = q.data or ""
    st = U(update.effective_user.id)
    if data == "x":
        await q.answer()
        return
    try:
        if data == "home":
            await q.answer()
            await q.edit_message_text(cur_line(st["model"]) + "\n\nاختر المزود:",
                                      reply_markup=kb_groups())
        elif data.startswith("g|"):
            _, gi, page = data.split("|")
            gi, page = int(gi), int(page)
            await q.answer()
            await q.edit_message_text(f"{GROUPS[gi]}\n{cur_line(st['model'])}",
                                      reply_markup=kb_models(gi, page, st["model"]))
        elif data.startswith("m|"):
            _, key, gi, page = data.split("|")
            if key not in MODELS:
                await q.answer("نموذج غير معروف", show_alert=True)
                return
            st["model"] = key
            save_state()
            log.info("user %s اختار النموذج %s", update.effective_user.id, key)
            await q.answer("✅ " + MODELS[key]["label"][:150])
            gi, page = int(gi), int(page)
            if gi >= 0:
                await q.edit_message_text(f"{GROUPS[gi]}\n{cur_line(key)}",
                                          reply_markup=kb_models(gi, page, key))
            else:
                await q.edit_message_text("✅ " + cur_line(key))
    except BadRequest as e:
        if "not modified" not in str(e).lower():
            raise


async def keep_typing(bot, chat_id):
    try:
        while True:
            await bot.send_chat_action(chat_id, ChatAction.TYPING)
            await asyncio.sleep(4)
    except asyncio.CancelledError:
        pass
    except Exception:  # noqa
        pass


@guarded
async def on_text(update, ctx):
    msg = update.message
    if not msg or not msg.text:
        return
    uid = update.effective_user.id
    st = U(uid)
    lock = LOCKS.setdefault(uid, asyncio.Lock())
    if lock.locked():
        await msg.reply_text("⏳ في طلب سابق لسا يشتغل، انتظر ينتهي...")
    async with lock:
        model = st["model"]
        info = model_info(model)
        log.info("TG <- %s [%s]: %s", uid, model, clip(msg.text, 200))
        placeholder = await msg.reply_text(f"⏳ {info['label']} ...")
        typing = asyncio.create_task(keep_typing(ctx.bot, msg.chat_id))
        try:
            res = await asyncio.to_thread(ask_with_retry, st, msg.text, model, info["mode"])
        finally:
            typing.cancel()
        save_state()

        if not res["ok"]:
            await placeholder.edit_text(f"❌ فشل الطلب\n{clip(res.get('error') or '?', 800)}\n\n(التفاصيل في اللوجس)")
            return

        text = res["text"]
        if res["urls"] and not text:
            text = "\n".join(res["urls"])
        elif res["urls"]:
            text += "\n\n" + "\n".join(u for u in res["urls"] if u not in text)
        footer = f"\n\n— 🤖 {info['label']}"
        dm = res.get("display_model")
        if dm and dm != model:
            footer += f" → {dm}"
        if res.get("note"):
            footer = f"\n\n{res['note']}" + footer
        await send_long(placeholder, msg.chat, text + footer)
        log.info("TG -> %s: %d حرف", uid, len(text))


async def on_error(update, ctx):
    log.error("Telegram error: %r", ctx.error)


async def post_init(app: Application):
    await app.bot.set_my_commands([
        BotCommand("models", "اختيار النموذج"),
        BotCommand("model", "اختيار نموذج بالاسم"),
        BotCommand("current", "الحالة الحالية"),
        BotCommand("new", "محادثة جديدة"),
        BotCommand("delete", "حذف المحادثة الحالية"),
        BotCommand("deleteall", "حذف كل المحادثات"),
        BotCommand("id", "رقم حسابك"),
    ])
    me = await app.bot.get_me()
    log.info("البوت شغال: @%s", me.username)


def main():
    setup_logging()
    if TELEGRAM_TOKEN.startswith("PUT_"):
        print("حط توكن بوت تلجرام في TELEGRAM_TOKEN داخل main.py (أو متغير بيئة TELEGRAM_TOKEN).")
        sys.exit(1)
    load_state()
    load_static_models()
    load_dynamic_models()
    finalize_registry()
    if DEFAULT_MODEL not in MODELS:
        log.warning("DEFAULT_MODEL=%s غير موجود في القائمة", DEFAULT_MODEL)

    app = (Application.builder().token(TELEGRAM_TOKEN)
           .concurrent_updates(True).post_init(post_init).build())
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_start))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CommandHandler("models", cmd_models))
    app.add_handler(CommandHandler("model", cmd_model))
    app.add_handler(CommandHandler("current", cmd_current))
    app.add_handler(CommandHandler("new", cmd_new))
    app.add_handler(CommandHandler("delete", cmd_delete))
    app.add_handler(CommandHandler("deleteall", cmd_deleteall))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_error_handler(on_error)
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
