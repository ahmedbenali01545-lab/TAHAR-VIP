extends CanvasLayer
class_name MobileHUD

signal jump_requested
signal run_toggled(value: bool)
signal sit_requested
signal interact_requested

var joystick: TouchJoystick
var _toast_label: Label
var _toast_timer: Timer
var _run_button: Button

const ICONS := {
	"run": "res://ui/icons/run.svg",
	"jump": "res://ui/icons/jump.svg",
	"sit": "res://ui/icons/sit.svg",
	"interact": "res://ui/icons/interact.svg"
}

func _ready() -> void:
	_build_ui()

func show_toast(message: String, duration: float = 2.7) -> void:
	if _toast_label == null:
		return
	_toast_label.text = message
	_toast_label.visible = true
	_toast_timer.start(duration)

func _build_ui() -> void:
	var root := Control.new()
	root.name = "HudRoot"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var title := Label.new()
	title.text = "COASTAL EXPLORER"
	title.position = Vector2(26, 22)
	title.size = Vector2(320, 34)
	title.add_theme_font_size_override("font_size", 23)
	title.add_theme_color_override("font_color", Color(0.96, 1.0, 1.0, 1.0))
	title.add_theme_color_override("font_outline_color", Color(0.02, 0.08, 0.11, 0.95))
	title.add_theme_constant_override("outline_size", 5)
	root.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "FOREST  •  HILLS  •  OCEAN"
	subtitle.position = Vector2(28, 56)
	subtitle.size = Vector2(320, 25)
	subtitle.add_theme_font_size_override("font_size", 12)
	subtitle.add_theme_color_override("font_color", Color(0.86, 0.96, 0.97, 0.9))
	subtitle.add_theme_color_override("font_outline_color", Color(0.02, 0.08, 0.11, 0.95))
	subtitle.add_theme_constant_override("outline_size", 3)
	root.add_child(subtitle)

	var objective := Label.new()
	objective.text = "استكشف الساحل وابحث عن المخيم"
	objective.position = Vector2(26, 88)
	objective.size = Vector2(360, 28)
	objective.add_theme_font_size_override("font_size", 15)
	objective.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0, 0.95))
	objective.add_theme_color_override("font_outline_color", Color(0.02, 0.08, 0.11, 0.95))
	objective.add_theme_constant_override("outline_size", 4)
	root.add_child(objective)

	joystick = TouchJoystick.new()
	joystick.name = "TouchJoystick"
	joystick.anchor_left = 0.0
	joystick.anchor_right = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 26.0
	joystick.offset_right = 190.0
	joystick.offset_top = -190.0
	joystick.offset_bottom = -26.0
	root.add_child(joystick)

	_add_action_button(root, "jump", Vector2(28, 112), Vector2(76, 76), false)
	_run_button = _add_action_button(root, "run", Vector2(116, 64), Vector2(68, 68), true)
	_add_action_button(root, "sit", Vector2(116, 146), Vector2(60, 60), false)
	_add_action_button(root, "interact", Vector2(28, 28), Vector2(60, 60), false)

	_toast_label = Label.new()
	_toast_label.visible = false
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast_label.anchor_left = 0.5
	_toast_label.anchor_right = 0.5
	_toast_label.anchor_top = 0.0
	_toast_label.anchor_bottom = 0.0
	_toast_label.offset_left = -220
	_toast_label.offset_right = 220
	_toast_label.offset_top = 24
	_toast_label.offset_bottom = 66
	_toast_label.add_theme_font_size_override("font_size", 18)
	_toast_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_toast_label.add_theme_stylebox_override("normal", _panel_style())
	root.add_child(_toast_label)

	_toast_timer = Timer.new()
	_toast_timer.one_shot = true
	_toast_timer.timeout.connect(func(): _toast_label.visible = false)
	add_child(_toast_timer)

func _add_action_button(root: Control, action: String, right_bottom_margin: Vector2, button_size: Vector2, is_toggle: bool) -> Button:
	var button := Button.new()
	button.name = action.capitalize() + "Button"
	button.text = ""
	button.custom_minimum_size = button_size
	button.size = button_size
	button.anchor_left = 1.0
	button.anchor_right = 1.0
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = -right_bottom_margin.x - button_size.x
	button.offset_right = -right_bottom_margin.x
	button.offset_top = -right_bottom_margin.y - button_size.y
	button.offset_bottom = -right_bottom_margin.y
	button.toggle_mode = is_toggle
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_stylebox_override("normal", _button_style(false))
	button.add_theme_stylebox_override("hover", _button_style(true))
	button.add_theme_stylebox_override("pressed", _button_style(true))
	button.add_theme_stylebox_override("focus", _button_style(false))
	root.add_child(button)

	var icon := TextureRect.new()
	icon.name = "Icon"
	icon.texture = load(ICONS[action]) as Texture2D
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var padding := 13.0 if button_size.x >= 68.0 else 11.0
	icon.offset_left = padding
	icon.offset_top = padding
	icon.offset_right = -padding
	icon.offset_bottom = -padding
	button.add_child(icon)

	match action:
		"jump": button.pressed.connect(func(): jump_requested.emit())
		"run": button.toggled.connect(func(value: bool): run_toggled.emit(value))
		"sit": button.pressed.connect(func(): sit_requested.emit())
		"interact": button.pressed.connect(func(): interact_requested.emit())
	return button

func _button_style(highlight: bool) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = Color(0.035, 0.095, 0.13, 0.76 if not highlight else 0.92)
	box.border_color = Color(0.60, 0.86, 0.91, 0.86)
	box.set_border_width_all(2)
	box.set_corner_radius_all(50)
	box.shadow_color = Color(0.01, 0.04, 0.06, 0.30)
	box.shadow_size = 5
	box.content_margin_left = 4
	box.content_margin_right = 4
	box.content_margin_top = 4
	box.content_margin_bottom = 4
	return box

func _panel_style() -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = Color(0.035, 0.095, 0.13, 0.78)
	box.border_color = Color(0.65, 0.86, 0.90, 0.60)
	box.set_border_width_all(1)
	box.set_corner_radius_all(12)
	box.content_margin_left = 16
	box.content_margin_right = 16
	box.content_margin_top = 7
	box.content_margin_bottom = 7
	return box
