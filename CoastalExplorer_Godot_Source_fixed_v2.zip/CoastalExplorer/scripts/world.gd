extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const HUD_SCRIPT = preload("res://scripts/mobile_hud.gd")
const ASSET_DIR := "res://assets/"

var player: ExplorerPlayer
var camera: Camera3D
var hud: MobileHUD
var camp_position := Vector3(5.0, 0.0, -7.5)
var _world_environment: WorldEnvironment
var _interactions_found := 0

func _ready() -> void:
	_setup_environment()
	_setup_landscape()
	_setup_player()
	_setup_camera()
	_setup_hud()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if hud != null:
		hud.show_toast("استخدم عصا التحكم للتحرك — W A S D على الكمبيوتر", 4.0)

func _process(delta: float) -> void:
	if player == null or camera == null:
		return
	var back := player.global_basis.z.normalized()
	var target_position := player.global_position + back * 5.7 + Vector3(0.0, 2.9, 0.0)
	camera.global_position = camera.global_position.lerp(target_position, minf(delta * 5.0, 1.0))
	camera.look_at(player.global_position + Vector3(0.0, 1.05, 0.0), Vector3.UP)

func _setup_environment() -> void:
	_world_environment = WorldEnvironment.new()
	_world_environment.name = "CoastalWorldEnvironment"
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.14, 0.36, 0.58)
	sky_material.sky_horizon_color = Color(0.69, 0.82, 0.88)
	sky_material.ground_bottom_color = Color(0.18, 0.25, 0.20)
	sky_material.ground_horizon_color = Color(0.60, 0.71, 0.67)
	sky_material.sun_angle_max = 18.0
	sky_material.sun_curve = 0.12
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.49, 0.62, 0.69)
	environment.ambient_light_energy = 0.78
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = Color(0.65, 0.76, 0.79)
	environment.fog_density = 0.003
	_world_environment.environment = environment
	add_child(_world_environment)

	var sun := DirectionalLight3D.new()
	sun.name = "WarmCoastalSun"
	sun.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	sun.light_color = Color(1.0, 0.91, 0.77)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 65.0
	add_child(sun)

func _setup_landscape() -> void:
	# The terrain, hill trail, sand, wet shoreline, and ocean were authored to align at the origin.
	var terrain := _add_asset("hill_terrain", Vector3.ZERO)
	_add_asset("hill_road", Vector3.ZERO)
	_add_asset("sand_surface", Vector3.ZERO)
	_add_asset("wet_sand", Vector3.ZERO)
	_add_asset("ocean", Vector3.ZERO)
	_add_asset("sky_clouds", Vector3.ZERO)
	_add_asset("shoreline_details", Vector3(0.0, 0.12, 3.7))

	# A broad hidden collision bed follows the beach footprint. The authored terrain meshes provide the hillside shape.
	var ground_body := StaticBody3D.new()
	ground_body.name = "BeachGroundCollision"
	var ground_shape := CollisionShape3D.new()
	var ground_box := BoxShape3D.new()
	ground_box.size = Vector3(29.2, 0.24, 31.0)
	ground_shape.shape = ground_box
	ground_shape.position = Vector3(0.0, -0.12, -9.5)
	ground_body.add_child(ground_shape)
	add_child(ground_body)

	# Keep the player on land while preserving the sea as a visible, non-walkable backdrop.
	var shore_barrier := StaticBody3D.new()
	shore_barrier.name = "ShorelineBoundary"
	var barrier_shape := CollisionShape3D.new()
	var barrier_box := BoxShape3D.new()
	barrier_box.size = Vector3(29.0, 3.0, 0.28)
	barrier_shape.shape = barrier_box
	barrier_shape.position = Vector3(0.0, 1.45, 5.65)
	shore_barrier.add_child(barrier_shape)
	add_child(shore_barrier)

	# Create an accurate static mesh collision surface for the rolling hills.
	var terrain_mesh := _find_mesh_instance(terrain)
	if terrain_mesh != null:
		terrain_mesh.create_trimesh_collision()

	# Forest edge and coastal plant life. The number of high-detail tree instances is kept limited for mobile performance.
	_add_tree("pine_tree", Vector3(-12.0, 0.25, -10.0), 0.15, 1.0)
	_add_tree("pine_tree", Vector3(12.0, 0.35, -12.4), -0.35, 1.0)
	_add_tree("pine_tree", Vector3(-14.0, 0.85, -19.0), 0.25, 0.96)
	_add_tree("oak_tree", Vector3(9.5, 0.55, -16.2), -0.18, 0.95)
	_add_tree("oak_tree", Vector3(-10.5, 1.0, -24.0), 0.55, 0.9)
	_add_tree("birch_tree", Vector3(14.0, 1.1, -25.8), 0.22, 1.05)
	_add_tree("birch_tree", Vector3(-16.0, 1.3, -31.0), -0.3, 1.0)
	_add_tree("oak_tree", Vector3(12.5, 1.65, -35.0), 0.2, 1.0)

	_add_asset("palm_tree", Vector3(-11.5, 0.35, 1.1), 0.25, Vector3(1.3, 1.3, 1.3))
	_add_asset("palm_tree", Vector3(11.8, 0.35, 0.5), -0.4, Vector3(1.25, 1.25, 1.25))
	_add_asset("palm_tree", Vector3(9.3, 0.35, -4.8), 0.7, Vector3(1.2, 1.2, 1.2))

	_add_asset("bush", Vector3(-8.7, 0.4, -7.8), 0.3, Vector3(1.15, 1.15, 1.15))
	_add_asset("bush", Vector3(8.3, 0.4, -8.6), -0.2, Vector3(1.1, 1.1, 1.1))
	_add_asset("bush", Vector3(-12.7, 0.45, -13.5), 0.9, Vector3(1.1, 1.1, 1.1))
	_add_asset("bush", Vector3(12.0, 0.5, -16.0), -0.5, Vector3(1.0, 1.0, 1.0))
	_add_asset("grass", Vector3(-5.2, 0.12, -6.2), 0.3, Vector3(1.0, 1.0, 1.0))
	_add_asset("grass", Vector3(5.0, 0.12, -5.2), -0.5, Vector3(1.0, 1.0, 1.0))
	_add_asset("grass", Vector3(-9.7, 0.15, -11.5), 0.4, Vector3(1.0, 1.0, 1.0))
	_add_asset("grass", Vector3(9.7, 0.15, -12.0), -0.1, Vector3(1.0, 1.0, 1.0))
	_add_asset("coastal_plants", Vector3(-13.2, 0.18, -2.8), 0.3)
	_add_asset("coastal_plants", Vector3(13.0, 0.18, -4.0), -0.25)
	_add_asset("tropical_plants", Vector3(-8.7, 0.15, -3.9), 0.5, Vector3(0.8, 0.8, 0.8))
	_add_asset("tropical_plants", Vector3(7.7, 0.15, -13.5), -0.2, Vector3(0.8, 0.8, 0.8))
	_add_asset("forest_ferns", Vector3(-11.0, 0.35, -16.5), 0.1, Vector3(1.0, 1.0, 1.0))
	_add_asset("forest_ferns", Vector3(11.0, 0.55, -21.2), 0.6, Vector3(1.0, 1.0, 1.0))
	_add_asset("forest_ferns", Vector3(-13.5, 0.65, -27.0), -0.3, Vector3(1.0, 1.0, 1.0))

	# Shore rocks and forest-floor detail.
	_add_asset("rock_1", Vector3(-13.0, 0.15, 3.2), 0.2, Vector3(1.0, 1.0, 1.0))
	_add_asset("rock_1", Vector3(12.0, 0.1, 3.8), -0.4, Vector3(0.9, 0.9, 0.9))
	_add_asset("rock_1", Vector3(-10.8, 0.15, -8.4), 0.8, Vector3(0.8, 0.8, 0.8))
	_add_asset("beach_rocks", Vector3(-7.8, 0.3, 4.0), 0.4, Vector3(1.2, 1.2, 1.2))
	_add_asset("beach_rocks", Vector3(7.6, 0.3, 4.1), -0.4, Vector3(1.15, 1.15, 1.15))
	_add_asset("log", Vector3(-5.6, 0.25, -8.9), -0.35, Vector3(1.0, 1.0, 1.0))
	_add_asset("log", Vector3(8.5, 0.25, -13.5), 0.7, Vector3(0.9, 0.9, 0.9))
	_add_asset("mushroom", Vector3(-8.8, 0.25, -13.7), 0.3, Vector3(0.6, 0.6, 0.6))
	_add_asset("mushroom", Vector3(10.5, 0.35, -21.5), -0.4, Vector3(0.55, 0.55, 0.55))

	# A small pond, a hillside waterfall, a bridge, and stepping-stone path dress the inland route.
	_add_asset("clear_pond", Vector3(-7.0, 0.45, -13.0), 0.12, Vector3(0.9, 0.9, 0.9))
	_add_asset("waterfall", Vector3(0.0, 2.7, -29.0))
	_add_asset("wooden_bridge", Vector3(3.7, 0.7, -15.2), PI * 0.5)
	_add_asset("stone_path", Vector3(0.0, 0.25, -26.0), 0.0, Vector3(1.0, 1.0, 1.0))

	# Exploreable campsite and equipment: these are the interaction target for the touch button.
	camp_position = Vector3(5.0, 0.0, -7.5)
	_add_asset("camp_site", Vector3(camp_position.x, 1.05, camp_position.z), -0.2, Vector3(1.0, 1.0, 1.0))
	_add_asset("explorer_gear", Vector3(8.5, 0.62, -9.0), 0.4, Vector3(0.85, 0.85, 0.85))

func _setup_player() -> void:
	player = PLAYER_SCRIPT.new() as ExplorerPlayer
	player.name = "Player"
	player.position = Vector3(0.0, 0.12, 1.1)
	add_child(player)
	var player_scene := load(ASSET_DIR + "player.glb") as PackedScene
	if player_scene == null:
		push_error("Could not load assets/player.glb")
		return
	var model := player_scene.instantiate() as Node3D
	if model == null:
		push_error("The player GLB did not instantiate as Node3D")
		return
	player.attach_visual(model)

func _setup_camera() -> void:
	camera = Camera3D.new()
	camera.name = "ThirdPersonCamera"
	camera.fov = 62.0
	camera.near = 0.1
	camera.far = 260.0
	camera.current = true
	add_child(camera)
	if player != null:
		camera.global_position = player.global_position + Vector3(0.0, 3.2, 6.3)
		camera.look_at(player.global_position + Vector3(0.0, 1.05, 0.0), Vector3.UP)

func _setup_hud() -> void:
	hud = HUD_SCRIPT.new() as MobileHUD
	add_child(hud)
	if player != null:
		player.attach_joystick(hud.joystick)
	hud.jump_requested.connect(_on_jump_requested)
	hud.run_toggled.connect(_on_run_toggled)
	hud.sit_requested.connect(_on_sit_requested)
	hud.interact_requested.connect(_on_interact_requested)

func _on_jump_requested() -> void:
	if player != null:
		player.request_jump()

func _on_run_toggled(value: bool) -> void:
	if player != null:
		player.set_running(value)

func _on_sit_requested() -> void:
	if player != null:
		player.toggle_sit()
		if hud != null:
			hud.show_toast("جلوس" if player.sitting else "العودة للحركة", 1.5)

func _on_interact_requested() -> void:
	if player == null or hud == null:
		return
	var player_flat := Vector2(player.global_position.x, player.global_position.z)
	var camp_flat := Vector2(camp_position.x, camp_position.z)
	if player_flat.distance_to(camp_flat) <= 4.2:
		_interactions_found += 1
		hud.show_toast("اكتشفت معدات المخيم!  •  %d" % _interactions_found, 2.8)
	else:
		hud.show_toast("اقترب من المخيم والمعدات للتفاعل", 2.4)

func _add_asset(asset_name: String, world_position: Vector3, yaw: float = 0.0, asset_scale: Vector3 = Vector3.ONE) -> Node3D:
	# Use merged-by-material assets on runtime to reduce draw calls; retain source GLBs in assets/.
	var optimized_path := "res://assets_optimized/" + asset_name + ".glb"
	var asset_path := optimized_path if ResourceLoader.exists(optimized_path) else ASSET_DIR + asset_name + ".glb"
	var packed := load(asset_path) as PackedScene
	if packed == null:
		push_warning("Missing GLB asset: " + asset_name)
		return null
	var instance := packed.instantiate() as Node3D
	if instance == null:
		push_warning("Could not instantiate GLB asset: " + asset_name)
		return null
	instance.name = asset_name.capitalize() + "_Instance_%d" % get_child_count()
	instance.position = world_position
	instance.rotation = Vector3(0.0, yaw, 0.0)
	instance.scale = asset_scale
	add_child(instance)
	return instance

func _add_tree(asset_name: String, world_position: Vector3, yaw: float, asset_scale: float) -> void:
	var tree := _add_asset(asset_name, world_position, yaw, Vector3.ONE * asset_scale)
	if tree == null:
		return
	var body := StaticBody3D.new()
	body.name = asset_name.capitalize() + "_TrunkCollision"
	body.position = world_position
	var shape := CollisionShape3D.new()
	var cylinder := CylinderShape3D.new()
	cylinder.radius = 0.32 * asset_scale
	cylinder.height = 2.6 * asset_scale
	shape.shape = cylinder
	shape.position = Vector3(0.0, 1.3 * asset_scale, 0.0)
	body.add_child(shape)
	add_child(body)

func _find_mesh_instance(node: Node) -> MeshInstance3D:
	if node is MeshInstance3D:
		return node as MeshInstance3D
	for child in node.get_children():
		var found := _find_mesh_instance(child)
		if found != null:
			return found
	return null
