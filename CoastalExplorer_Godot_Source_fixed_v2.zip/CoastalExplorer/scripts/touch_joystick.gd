extends Control
class_name TouchJoystick

signal vector_changed(value: Vector2)

var _value: Vector2 = Vector2.ZERO
var _active := false
var _finger_index := -1
var _mouse_active := false

func _ready() -> void:
	custom_minimum_size = Vector2(164, 164)
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func get_vector() -> Vector2:
	return _value

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and not _active:
			_active = true
			_finger_index = event.index
			_update_value(event.position)
			accept_event()
		elif not event.pressed and _active and event.index == _finger_index:
			_reset_value()
			_finger_index = -1
			accept_event()
	elif event is InputEventScreenDrag and _active and event.index == _finger_index:
		_update_value(event.position)
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_mouse_active = true
			_update_value(event.position)
		else:
			_mouse_active = false
			_reset_value()
		accept_event()
	elif event is InputEventMouseMotion and _mouse_active:
		_update_value(event.position)
		accept_event()

func _update_value(pointer_position: Vector2) -> void:
	var center := size * 0.5
	var radius: float = minf(size.x, size.y) * 0.36
	var offset: Vector2 = (pointer_position - center) / maxf(radius, 1.0)
	_value = offset.limit_length(1.0)
	if _value.length() < 0.12:
		_value = Vector2.ZERO
	queue_redraw()
	vector_changed.emit(_value)

func _reset_value() -> void:
	_value = Vector2.ZERO
	queue_redraw()
	vector_changed.emit(_value)

func _draw() -> void:
	var center := size * 0.5
	var radius: float = minf(size.x, size.y) * 0.43
	draw_circle(center + Vector2(0, 3), radius, Color(0.02, 0.05, 0.08, 0.24))
	draw_circle(center, radius, Color(0.04, 0.10, 0.14, 0.52))
	draw_arc(center, radius, 0.0, TAU, 64, Color(0.77, 0.91, 0.95, 0.68), 2.0, true)
	var knob_center := center + _value * radius * 0.60
	draw_circle(knob_center + Vector2(0, 2), radius * 0.43, Color(0.01, 0.04, 0.06, 0.30))
	draw_circle(knob_center, radius * 0.43, Color(0.70, 0.87, 0.91, 0.52))
	draw_arc(knob_center, radius * 0.43, 0.0, TAU, 48, Color(0.95, 1.0, 1.0, 0.90), 2.0, true)
