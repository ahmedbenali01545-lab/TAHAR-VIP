extends CharacterBody3D
class_name ExplorerPlayer

@export var walk_speed: float = 3.5
@export var run_speed: float = 5.8
@export var acceleration: float = 13.0
@export var jump_velocity: float = 5.1
@export var rotation_speed: float = 9.0

var joystick: TouchJoystick
var animation_player: AnimationPlayer
var visual_root: Node3D
var running := false
var sitting := false
var _jump_requested := false
var _current_animation := ""
var _gravity: float = float(ProjectSettings.get_setting("physics/3d/default_gravity"))

func _ready() -> void:
	floor_snap_length = 0.28
	floor_max_angle = deg_to_rad(48.0)
	_setup_collision()

func attach_visual(model: Node3D) -> void:
	visual_root = model
	add_child(visual_root)
	visual_root.position = Vector3.ZERO
	animation_player = _find_animation_player(visual_root)
	_play_animation("idle")

func attach_joystick(control: TouchJoystick) -> void:
	joystick = control

func set_running(value: bool) -> void:
	running = value

func request_jump() -> void:
	_jump_requested = true
	if sitting:
		sitting = false

func toggle_sit() -> void:
	sitting = not sitting
	if sitting:
		velocity.x = 0.0
		velocity.z = 0.0
		_play_animation("sit")
	else:
		_play_animation("idle")

func _physics_process(delta: float) -> void:
	var move_vector := _get_move_vector()
	if sitting and move_vector.length() > 0.18:
		sitting = false
	if sitting:
		velocity.x = move_toward(velocity.x, 0.0, acceleration * delta)
		velocity.z = move_toward(velocity.z, 0.0, acceleration * delta)
	else:
		var direction := Vector3(move_vector.x, 0.0, move_vector.y)
		if direction.length() > 1.0:
			direction = direction.normalized()
		var speed := run_speed if (running or Input.is_key_pressed(KEY_SHIFT)) else walk_speed
		var target_x := direction.x * speed
		var target_z := direction.z * speed
		velocity.x = move_toward(velocity.x, target_x, acceleration * delta)
		velocity.z = move_toward(velocity.z, target_z, acceleration * delta)
		if direction.length() > 0.08:
			var target_rotation := atan2(-direction.x, -direction.z)
			rotation.y = lerp_angle(rotation.y, target_rotation, minf(rotation_speed * delta, 1.0))

	if not is_on_floor():
		velocity.y -= _gravity * delta
	elif _jump_requested and not sitting:
		velocity.y = jump_velocity
		_play_animation("jump")
	_jump_requested = false

	move_and_slide()
	_update_animation(move_vector)

func _get_move_vector() -> Vector2:
	var result := Vector2.ZERO
	if joystick != null:
		result = joystick.get_vector()
	var keyboard := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		keyboard.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		keyboard.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		keyboard.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		keyboard.y += 1.0
	if keyboard.length() > 0.0:
		result = keyboard.normalized()
	return result.limit_length(1.0)

func _setup_collision() -> void:
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.62
	var collision := CollisionShape3D.new()
	collision.name = "PlayerCapsule"
	collision.shape = capsule
	collision.position = Vector3(0.0, 0.81, 0.0)
	add_child(collision)

func _update_animation(move_vector: Vector2) -> void:
	if sitting:
		_play_animation("sit")
		return
	if not is_on_floor():
		if _current_animation != "jump":
			_play_animation("jump")
		return
	if move_vector.length() > 0.12:
		_play_animation("run" if (running or Input.is_key_pressed(KEY_SHIFT)) else "walk")
	else:
		_play_animation("idle")

func _play_animation(animation_key: String) -> void:
	if animation_key == _current_animation:
		return
	_current_animation = animation_key
	if animation_player == null:
		return
	for candidate in animation_player.get_animation_list():
		var bare_name := candidate.get_slice("/", candidate.get_slice_count("/") - 1).to_lower()
		if bare_name == animation_key.to_lower():
			animation_player.play(candidate, 0.16)
			return

func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null
