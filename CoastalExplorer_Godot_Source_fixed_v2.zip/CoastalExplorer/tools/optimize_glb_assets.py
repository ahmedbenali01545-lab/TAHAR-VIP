#!/usr/bin/env python3
"""Merge static, untextured GLB prop parts by material to reduce Android draw calls.

The supplied GLBs use solid-color PBR materials rather than external texture images.
Transforms are baked into each sub-mesh, then geometry is merged per unique material.
Animated character and already-simple terrain/water assets are intentionally skipped.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import trimesh

SKIP = {
    "player.glb",          # preserve armature and all five animations
    "hill_terrain.glb",    # one large mesh; no optimization needed
    "hill_road.glb",       # one large mesh; no optimization needed
    "sand_surface.glb",    # one mesh
    "wet_sand.glb",        # one mesh
    "ocean.glb",           # two meshes (water and foam)
    "sunlight_setup.glb",  # contains a punctual light; lighting is recreated in Godot
}


def _material_signature(mesh: trimesh.Trimesh, fallback_name: str) -> tuple[str, str]:
    visual = getattr(mesh, "visual", None)
    material = getattr(visual, "material", None)
    name = str(getattr(material, "name", "") or fallback_name or "Material")
    factor = getattr(material, "baseColorFactor", None)
    if factor is None:
        color = getattr(visual, "main_color", None)
        factor_tuple = tuple(int(x) for x in color) if color is not None else (200, 200, 200, 255)
    else:
        factor_tuple = tuple(float(x) for x in np.asarray(factor).reshape(-1).tolist())
    metallic = float(getattr(material, "metallicFactor", 0.0) or 0.0)
    roughness = float(getattr(material, "roughnessFactor", 1.0) if getattr(material, "roughnessFactor", None) is not None else 1.0)
    signature = json.dumps([name, factor_tuple, metallic, roughness], separators=(",", ":"))
    return signature, name


def optimize_one(source: Path, destination: Path) -> dict[str, object]:
    scene = trimesh.load(source, force="scene", process=False)
    groups: dict[str, list[trimesh.Trimesh]] = defaultdict(list)
    materials: dict[str, object] = {}
    names: dict[str, str] = {}

    for node_name in scene.graph.nodes_geometry:
        transform, geometry_name = scene.graph.get(node_name)
        geometry = scene.geometry[geometry_name]
        if not isinstance(geometry, trimesh.Trimesh) or len(geometry.faces) == 0:
            continue
        baked = geometry.copy()
        baked.apply_transform(transform)
        signature, material_name = _material_signature(baked, str(geometry_name))
        groups[signature].append(baked)
        names[signature] = material_name
        material = getattr(getattr(baked, "visual", None), "material", None)
        if material is not None:
            materials[signature] = material.copy() if hasattr(material, "copy") else material

    if not groups:
        raise RuntimeError(f"No triangle meshes found in {source.name}")

    merged_scene = trimesh.Scene()
    for index, (signature, chunks) in enumerate(groups.items()):
        merged = trimesh.util.concatenate(chunks)
        if signature in materials:
            merged.visual = trimesh.visual.TextureVisuals(material=materials[signature])
        safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", names[signature]).strip("_") or "Material"
        merged_name = f"{safe_name}_{index:02d}"
        merged_scene.add_geometry(merged, geom_name=merged_name, node_name=merged_name, transform=np.eye(4))

    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(merged_scene.export(file_type="glb"))

    check = trimesh.load(destination, force="scene", process=False)
    if len(check.graph.nodes_geometry) > len(groups) + 1:
        raise RuntimeError(f"Mesh merge did not reduce node count for {source.name}")
    if source.stat().st_size and destination.stat().st_size > source.stat().st_size * 1.5:
        raise RuntimeError(f"Optimized GLB unexpectedly grew: {source.name}")
    return {
        "source": source.name,
        "source_nodes": len(scene.graph.nodes_geometry),
        "optimized_nodes": len(check.graph.nodes_geometry),
        "materials": len(groups),
        "source_bytes": source.stat().st_size,
        "optimized_bytes": destination.stat().st_size,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("assets"))
    parser.add_argument("--output", type=Path, default=Path("assets_optimized"))
    args = parser.parse_args()
    reports = []
    for source in sorted(args.source.glob("*.glb")):
        if source.name in SKIP:
            continue
        report = optimize_one(source, args.output / source.name)
        reports.append(report)
        print(f"{report['source']}: {report['source_nodes']} -> {report['optimized_nodes']} mesh nodes; "
              f"{report['source_bytes']} -> {report['optimized_bytes']} bytes")
    print(f"Optimized {len(reports)} static GLB assets into {args.output}")


if __name__ == "__main__":
    main()
