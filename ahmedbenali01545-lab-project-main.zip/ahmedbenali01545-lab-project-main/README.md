# Personal Profile Website / موقع صفحة شخصية

موقع شخصي احترافي يشبه **Linktree** بتصميم فاخر (خلفية سوداء، إطارات رمادية متوهجة) ولوحة تحكم كاملة لإدارة الموقع دون تعديل الكود.

A professional Linktree-style personal page with a luxurious black design (gray glowing borders) and a full admin dashboard to manage everything without touching the code.

---

## المميزات / Features

- خلفية سوداء بالكامل، نصوص بيضاء، تصميم Minimal متجاوب.
- صورة شخصية دائرية (رفع أو رابط مباشر، PNG/JPG/WebP).
- بطاقات عمودية بإطار رمادي متوهج عند المرور.
- **الرابط الحقيقي لا يظهر أبدًا** — يُعرض اسم مخصص فقط.
- دعم كل أنواع المحتوى: تواصل اجتماعي، مواقع، تطبيقات، ألعاب، PDF (تحميل مباشر)، روابط تحميل، مشاريع، مقالات، أي رابط.
- لوحة تحكم محمية على `/admin`: إضافة/تعديل/حذف، سحب وإفلات للترتيب، إظهار/إخفاء، عدد غير محدود.
- SEO جيد، Lazy Loading، وضع داكن كامل.

---

## التقنيات / Tech stack

Next.js (App Router) · TypeScript · Tailwind CSS · Prisma · SQLite (افتراضيًا / default).

---

## التشغيل محليًا / Run locally

```bash
npm install
cp .env.example .env   # ثم عدّل ADMIN_PASSWORD و AUTH_SECRET
npx prisma db push
npm run db:seed
npm run dev
```

افتح `http://localhost:3000` للموقع، و `http://localhost:3000/admin` للوحة التحكم. سجّل الدخول بـ `ADMIN_PASSWORD`.

---

## الصورة الشخصية / Profile image

وُضعت صورة افتراضية في `public/images/profile.svg`. سجّل الدخول لـ `/admin` وارفع صورتك أو ضع رابطًا مباشرًا.

> ملاحظة: الصورة الافتراضية placeholder، لأنني لا أستطيع استقبال صورتك المرجعية داخل المحادثة.

---

## النشر المجاني / Free deployment

### GitLab Pages؟
**لا** — GitLab Pages يدعم المواقع الثابتة فقط ولا يشغّل الـ backend / قاعدة البيانات. استخدم **Vercel** (الأسهل) أو Railway أو Render. يبقى الكود في GitLab وتربطه بـ Vercel.

### Vercel خطوة بخطوة
1. افتح [vercel.com](https://vercel.com) وسجّل بحساب GitLab.
2. **Add New → Project** ثم اختر هذا المستودع.
3. أضف Environment Variables: `ADMIN_PASSWORD`، `AUTH_SECRET`، `DATABASE_URL`.
4. **Deploy**.

### ⚠️ قاعدة البيانات للإنتاج / Production DB
على Vercel التخزين مؤقت، فملف SQLite يُحذف عند كل إعادة نشر. للإنتاج استخدم قاعدة دائمة:
- **Turso** (SQLite سحابي): غيّر `DATABASE_URL` فقط.
- **Postgres** (Neon / Vercel Postgres): غيّر `provider` في `prisma/schema.prisma` إلى `postgresql` ثم ضع `DATABASE_URL`.

> رفع الصور عبر اللوحة يُحفظ في `public/uploads` وهو أيضًا مؤقت على Vercel. للإنتاج يُفضّل روابط صور مباشرة أو تخزين خارجي (Cloudinary).

---

## البنية / Structure

```
prisma/        schema.prisma + seed.ts
public/        images/ + uploads/
src/app/       page.tsx + admin/ + api/
src/components/ البطاقات واللوحة
src/lib/       prisma + auth
src/middleware.ts حماية /admin
```

---

## الأمان / Security
غيّر `ADMIN_PASSWORD` و `AUTH_SECRET` دائمًا قبل النشر. لا ترفع `.env` إلى المستودع.
