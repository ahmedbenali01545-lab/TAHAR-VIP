import { prisma } from '@/lib/prisma';
import Avatar from '@/components/Avatar';
import LinkCard from '@/components/LinkCard';

// تحديث البيانات دائمًا / Always fresh data
export const dynamic = 'force-dynamic';

export default async function HomePage() {
  let name = 'My Name';
  let bio = '';
  let avatarUrl = '/images/profile.svg';
  let cards: any[] = [];

  try {
    const profile = await prisma.profile.findUnique({ where: { id: 1 } });
    if (profile) {
      name = profile.name;
      bio = profile.bio;
      avatarUrl = profile.avatarUrl;
    }
    cards = await prisma.card.findMany({
      where: { visible: true },
      orderBy: { position: 'asc' }
    });
  } catch {
    // قاعدة البيانات غير جاهزة / DB not ready
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col items-center px-5 py-12">
      <Avatar src={avatarUrl} alt={name} />
      <h1 className="mt-5 text-center text-2xl font-semibold text-white">{name}</h1>
      {bio ? <p className="mt-2 max-w-md text-center text-sm text-white/70">{bio}</p> : null}

      <section className="mt-8 flex w-full flex-col gap-4">
        {cards.length === 0 ? (
          <p className="text-center text-sm text-white/50">
            لا توجد بطاقات بعد. أضفها من لوحة التحكم / No cards yet. Add from /admin
          </p>
        ) : (
          cards.map((c) => <LinkCard key={c.id} card={c} />)
        )}
      </section>

      <footer className="mt-12 text-center text-xs text-white/30">
        <a href="/admin" className="hover:text-white/60">Admin</a>
      </footer>
    </main>
  );
}
