'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

// صفحة تسجيل الدخول للوحة التحكم / Admin login page
export default function LoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    setLoading(false);
    if (res.ok) {
      router.push('/admin');
      router.refresh();
    } else {
      const data = await res.json();
      setError(data.error || 'Error');
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-2xl border border-border bg-black p-6"
      >
        <h1 className="mb-1 text-xl font-semibold text-white">لوحة التحكم</h1>
        <p className="mb-5 text-sm text-white/60">Admin Dashboard</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="كلمة المرور / Password"
          className="w-full rounded-lg border border-border bg-black px-3 py-2 text-white outline-none focus:border-borderHover"
          autoFocus
        />
        {error ? <p className="mt-3 text-sm text-red-400">{error}</p> : null}
        <button
          type="submit"
          disabled={loading}
          className="mt-5 w-full rounded-lg border border-border bg-black py-2 text-white transition-all hover:border-borderHover hover:shadow-glow disabled:opacity-50"
        >
          {loading ? '...' : 'دخول / Login'}
        </button>
      </form>
    </main>
  );
}
