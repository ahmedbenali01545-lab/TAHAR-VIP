import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { isAuthenticated } from '@/lib/auth';

// تعديل بطاقة / Update card
export async function PUT(req: Request, { params }: { params: { id: string } }) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const card = await prisma.card.update({
    where: { id: params.id },
    data: {
      title: body.title,
      description: body.description,
      url: body.url,
      imageUrl: body.imageUrl,
      type: body.type,
      visible: body.visible
    }
  });
  return NextResponse.json(card);
}

// حذف بطاقة / Delete card
export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  await prisma.card.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
