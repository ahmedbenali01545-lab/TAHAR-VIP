import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { isAuthenticated } from '@/lib/auth';

// جلب كل البطاقات (للوحة التحكم) / Get all cards (for admin)
export async function GET() {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const cards = await prisma.card.findMany({ orderBy: { position: 'asc' } });
  return NextResponse.json(cards);
}

// إضافة بطاقة / Create card
export async function POST(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const max = await prisma.card.aggregate({ _max: { position: true } });
  const card = await prisma.card.create({
    data: {
      title: body.title ?? 'New Card',
      description: body.description ?? '',
      url: body.url ?? '',
      imageUrl: body.imageUrl ?? '',
      type: body.type ?? 'link',
      visible: body.visible ?? true,
      position: (max._max.position ?? -1) + 1
    }
  });
  return NextResponse.json(card);
}

// تغيير الترتيب (سحب وإفلات) / Reorder (drag & drop)
export async function PATCH(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json(); // { ids: string[] }
  const ids: string[] = body.ids ?? [];
  await prisma.$transaction(
    ids.map((id, index) =>
      prisma.card.update({ where: { id }, data: { position: index } })
    )
  );
  return NextResponse.json({ ok: true });
}
