import { NextResponse } from 'next/server';
import { createSession } from '@/lib/auth';

// تسجيل الدخول بكلمة المرور / Login with password
export async function POST(req: Request) {
  const { password } = await req.json();
  const expected = process.env.ADMIN_PASSWORD || 'change-me-please';

  if (!password || password !== expected) {
    return NextResponse.json({ error: 'كلمة المرور غير صحيحة / Wrong password' }, { status: 401 });
  }

  await createSession();
  return NextResponse.json({ ok: true });
}
