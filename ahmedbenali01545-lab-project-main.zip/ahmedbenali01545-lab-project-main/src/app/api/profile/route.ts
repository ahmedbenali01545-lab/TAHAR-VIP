import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { isAuthenticated } from '@/lib/auth';

// جلب الملف الشخصي / Get profile
export async function GET() {
  const profile = await prisma.profile.findUnique({ where: { id: 1 } });
  return NextResponse.json(profile);
}

// تحديث الملف الشخصي (محمي) / Update profile (protected)
export async function PUT(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const profile = await prisma.profile.upsert({
    where: { id: 1 },
    update: {
      name: body.name,
      bio: body.bio,
      avatarUrl: body.avatarUrl
    },
    create: {
      id: 1,
      name: body.name ?? 'My Name',
      bio: body.bio ?? '',
      avatarUrl: body.avatarUrl ?? '/images/profile.svg'
    }
  });
  return NextResponse.json(profile);
}
