import type { Metadata } from 'next';
import './globals.css';
import { prisma } from '@/lib/prisma';

// SEO ديناميكي من قاعدة البيانات / Dynamic SEO from database
export async function generateMetadata(): Promise<Metadata> {
  let name = 'Personal Page';
  let bio = 'My links and content';
  try {
    const profile = await prisma.profile.findUnique({ where: { id: 1 } });
    if (profile) {
      name = profile.name;
      bio = profile.bio || bio;
    }
  } catch {
    // قاعدة البيانات غير جاهزة بعد / DB not ready yet
  }
  return {
    title: name,
    description: bio,
    openGraph: { title: name, description: bio, type: 'website' },
    twitter: { card: 'summary', title: name, description: bio }
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="auto">
      <body>{children}</body>
    </html>
  );
}
