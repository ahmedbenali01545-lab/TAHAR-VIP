import type { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.SITE_URL || 'https://example.com';
  return [
    { url: base, lastModified: new Date(), changeFrequency: 'weekly', priority: 1 }
  ];
}
