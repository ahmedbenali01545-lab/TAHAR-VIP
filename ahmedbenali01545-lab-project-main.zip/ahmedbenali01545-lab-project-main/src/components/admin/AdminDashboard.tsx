/* eslint-disable @next/next/no-img-element */
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import ImageInput from './ImageInput';

type Card = {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl: string;
  type: string;
  visible: boolean;
  position: number;
};

type Profile = { name: string; bio: string; avatarUrl: string };

const TYPES = ['link', 'social', 'website', 'app', 'game', 'pdf', 'download', 'project', 'article', 'other'];

export default function AdminDashboard() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile>({ name: '', bio: '', avatarUrl: '' });
  const [cards, setCards] = useState<Card[]>([]);
  const [loading, setLoading] = useState(true);
  const [dragId, setDragId] = useState<string | null>(null);

  async function load() {
    const [p, c] = await Promise.all([
      fetch('/api/profile').then((r) => r.json()),
      fetch('/api/cards').then((r) => (r.ok ? r.json() : []))
    ]);
    if (p) setProfile({ name: p.name, bio: p.bio, avatarUrl: p.avatarUrl });
    setCards(c);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function saveProfile() {
    await fetch('/api/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    });
    alert('تم الحفظ / Saved');
  }

  async function addCard() {
    const res = await fetch('/api/cards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'New Card', url: '', type: 'link' })
    });
    const card = await res.json();
    setCards((prev) => [...prev, card]);
  }

  async function updateCard(card: Card) {
    await fetch(`/api/cards/${card.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(card)
    });
  }

  async function deleteCard(id: string) {
    if (!confirm('حذف البطاقة؟ / Delete card?')) return;
    await fetch(`/api/cards/${id}`, { method: 'DELETE' });
    setCards((prev) => prev.filter((c) => c.id !== id));
  }

  function setField(id: string, field: keyof Card, value: any) {
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, [field]: value } : c)));
  }

  async function persistOrder(list: Card[]) {
    await fetch('/api/cards', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: list.map((c) => c.id) })
    });
  }

  function onDrop(targetId: string) {
    if (!dragId || dragId === targetId) return;
    const from = cards.findIndex((c) => c.id === dragId);
    const to = cards.findIndex((c) => c.id === targetId);
    const next = [...cards];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    setCards(next);
    setDragId(null);
    persistOrder(next);
  }

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  if (loading) return <main className="p-8 text-white/60">...</main>;

  return (
    <main className="mx-auto max-w-2xl px-5 py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold">لوحة التحكم / Admin</h1>
        <div className="flex gap-2">
          <a href="/" className="rounded-lg border border-border px-3 py-1 text-sm hover:border-borderHover">الموقع</a>
          <button onClick={logout} className="rounded-lg border border-border px-3 py-1 text-sm hover:border-borderHover">خروج</button>
        </div>
      </div>

      {/* الملف الشخصي / Profile */}
      <section className="mb-8 rounded-2xl border border-border p-4">
        <h2 className="mb-4 text-sm font-medium text-white/80">الملف الشخصي / Profile</h2>
        <div className="space-y-3">
          <input
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            placeholder="الاسم / Name"
            className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
          />
          <textarea
            value={profile.bio}
            onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
            placeholder="الوصف / Bio"
            rows={2}
            className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
          />
          <ImageInput
            label="الصورة الشخصية / Profile picture"
            value={profile.avatarUrl}
            onChange={(url) => setProfile({ ...profile, avatarUrl: url })}
          />
          {profile.avatarUrl ? (
            <img src={profile.avatarUrl} alt="" className="h-20 w-20 rounded-full border border-border object-cover" />
          ) : null}
          <button onClick={saveProfile} className="rounded-lg border border-border px-4 py-2 text-sm hover:border-borderHover hover:shadow-glow">حفظ / Save</button>
        </div>
      </section>

      {/* البطاقات / Cards */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-medium text-white/80">البطاقات / Cards</h2>
          <button onClick={addCard} className="rounded-lg border border-border px-4 py-2 text-sm hover:border-borderHover hover:shadow-glow">+ إضافة / Add</button>
        </div>

        <div className="space-y-4">
          {cards.map((card) => (
            <div
              key={card.id}
              draggable
              onDragStart={() => setDragId(card.id)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onDrop(card.id)}
              className="rounded-2xl border border-border p-4"
            >
              <div className="mb-3 flex items-center justify-between">
                <span className="cursor-grab text-white/40" title="اسحب للترتيب / Drag to reorder">☰</span>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1 text-xs text-white/60">
                    <input
                      type="checkbox"
                      checked={card.visible}
                      onChange={(e) => setField(card.id, 'visible', e.target.checked)}
                    />
                    ظاهر / Visible
                  </label>
                  <button onClick={() => deleteCard(card.id)} className="text-xs text-red-400 hover:text-red-300">حذف / Delete</button>
                </div>
              </div>

              <div className="space-y-3">
                <input
                  value={card.title}
                  onChange={(e) => setField(card.id, 'title', e.target.value)}
                  placeholder="الاسم المعروض (مثل Instagram) / Display name"
                  className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
                />
                <input
                  value={card.description}
                  onChange={(e) => setField(card.id, 'description', e.target.value)}
                  placeholder="الوصف (اختياري) / Description (optional)"
                  className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
                />
                <input
                  value={card.url}
                  onChange={(e) => setField(card.id, 'url', e.target.value)}
                  placeholder="الرابط الحقيقي / Real URL"
                  className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
                />
                <select
                  value={card.type}
                  onChange={(e) => setField(card.id, 'type', e.target.value)}
                  className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm outline-none focus:border-borderHover"
                >
                  {TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                <ImageInput
                  label="صورة البطاقة / Card image"
                  value={card.imageUrl}
                  onChange={(url) => setField(card.id, 'imageUrl', url)}
                />
                <button
                  onClick={() => updateCard(card)}
                  className="rounded-lg border border-border px-4 py-2 text-sm hover:border-borderHover hover:shadow-glow"
                >
                  حفظ البطاقة / Save card
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
