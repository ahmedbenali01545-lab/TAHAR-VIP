'use client';

import { useState } from 'react';

// إدخال صورة: رابط مباشر أو رفع ملف / Image input: direct URL or file upload
export default function ImageInput({
  value,
  onChange,
  label
}: {
  value: string;
  onChange: (url: string) => void;
  label: string;
}) {
  const [uploading, setUploading] = useState(false);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch('/api/upload', { method: 'POST', body: fd });
    setUploading(false);
    if (res.ok) {
      const data = await res.json();
      onChange(data.url);
    } else {
      const data = await res.json();
      alert(data.error || 'Upload failed');
    }
  }

  return (
    <div className="space-y-2">
      <label className="text-sm text-white/70">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="https://... أو ارفع ملفًا / or upload a file"
        className="w-full rounded-lg border border-border bg-black px-3 py-2 text-sm text-white outline-none focus:border-borderHover"
      />
      <div className="flex items-center gap-3">
        <input
          type="file"
          accept="image/png,image/jpeg,image/webp"
          onChange={handleFile}
          className="text-xs text-white/60 file:mr-3 file:rounded-md file:border file:border-border file:bg-black file:px-3 file:py-1 file:text-white"
        />
        {uploading ? <span className="text-xs text-white/50">...</span> : null}
      </div>
    </div>
  );
}
