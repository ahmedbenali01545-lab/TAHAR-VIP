/* eslint-disable @next/next/no-img-element */
'use client';

export type CardData = {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl: string;
  type: string;
};

// هل الرابط ملف PDF ؟ / Is the link a PDF file?
function isPdf(card: CardData) {
  return card.type === 'pdf' || card.url.toLowerCase().endsWith('.pdf');
}

// بطاقة رابط: تعرض اسمًا مخصصًا فقط (لا تعرض الرابط الحقيقي)
// Link card: shows a custom name only (never the real URL)
export default function LinkCard({ card }: { card: CardData }) {
  const pdf = isPdf(card);
  return (
    <a
      href={card.url}
      target="_blank"
      rel="noopener noreferrer"
      {...(pdf ? { download: '' } : {})}
      className="group block w-full rounded-2xl border border-border bg-black px-4 py-4 transition-all duration-200 ease-out hover:border-borderHover hover:shadow-glow focus:outline-none focus-visible:border-borderHover focus-visible:shadow-glow active:shadow-glow"
    >
      <div className="flex items-center gap-4">
        {card.imageUrl ? (
          <img
            src={card.imageUrl}
            alt=""
            loading="lazy"
            className="h-12 w-12 flex-shrink-0 rounded-lg object-contain"
          />
        ) : (
          <div className="h-12 w-12 flex-shrink-0 rounded-lg border border-border" />
        )}
        <div className="min-w-0 flex-1">
          <div className="truncate text-base font-medium text-white">{card.title}</div>
          {card.description ? (
            <div className="truncate text-sm text-white/70">{card.description}</div>
          ) : null}
        </div>
      </div>
    </a>
  );
}
