/* eslint-disable @next/next/no-img-element */
'use client';

// صورة شخصية دائرية بجودة عالية / High quality circular avatar
export default function Avatar({ src, alt }: { src: string; alt: string }) {
  return (
    <div className="flex justify-center">
      <div className="relative h-32 w-32 sm:h-36 sm:w-36 overflow-hidden rounded-full border border-border">
        <img
          src={src || '/images/profile.svg'}
          alt={alt}
          loading="eager"
          className="h-full w-full object-cover"
        />
      </div>
    </div>
  );
}
