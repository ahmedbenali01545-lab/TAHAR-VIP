import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        bg: '#000000',
        fg: '#ffffff',
        border: '#3a3a3a',
        borderHover: '#8a8a8a'
      },
      boxShadow: {
        glow: '0 0 0 1px #8a8a8a, 0 0 18px 2px rgba(160,160,160,0.45)'
      }
    }
  },
  plugins: []
};

export default config;
