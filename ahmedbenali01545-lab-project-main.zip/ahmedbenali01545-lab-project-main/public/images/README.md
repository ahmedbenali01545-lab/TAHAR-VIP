# الصورة الشخصية / Profile image

ضع صورتك الشخصية هنا. Place your profile image in this folder.

- الأسهل: سجّل الدخول لـ `/admin` وارفع الصورة أو ضع رابطًا مباشرًا.
- الصورة الافتراضية الحالية هي `profile.svg` (placeholder).
