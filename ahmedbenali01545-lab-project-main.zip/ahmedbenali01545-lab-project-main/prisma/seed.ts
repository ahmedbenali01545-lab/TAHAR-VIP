import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // إنشاء ملف الصفحة الافتراضي / Create default profile
  await prisma.profile.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      name: 'My Name',
      bio: 'مرحبًا بك في صفحتي الشخصية / Welcome to my page',
      avatarUrl: '/images/profile.svg'
    }
  });

  const count = await prisma.card.count();
  if (count === 0) {
    await prisma.card.createMany({
      data: [
        { title: 'Instagram', description: '', url: 'https://instagram.com', type: 'social', position: 0 },
        { title: 'My Portfolio', description: 'أعمالي', url: 'https://example.com', type: 'website', position: 1 },
        { title: 'Download CV', description: 'PDF', url: 'https://example.com/cv.pdf', type: 'pdf', position: 2 }
      ]
    });
  }
  console.log('Seed done.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
