لتعديل AndroidManifest.xml:
1) حمّل artifact باسم "AndroidManifest" من أول بناء ناجح.
2) عدّله وضعه هنا باسم AndroidManifest.xml
3) الـ workflow ينسخه فوق ملف القالب تلقائيًا قبل البناء.
