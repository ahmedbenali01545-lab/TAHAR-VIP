extends Control
## عصا حركة على اليسار + سحب على اليمين للنظر

const JOY_RADIUS := 110.0
const KNOB_RADIUS := 46.0

var move := Vector2.ZERO
var look_delta := Vector2.ZERO

var _joy_id := -1
var _look_id := -1
var _origin := Vector2.ZERO
var _knob := Vector2.ZERO


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	get_viewport().size_changed.connect(queue_redraw)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		_on_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_on_drag(event as InputEventScreenDrag)


func _on_touch(e: InputEventScreenTouch) -> void:
	var half := get_viewport_rect().size.x * 0.5
	if e.pressed:
		if e.position.x < half:
			if _joy_id == -1:
				_joy_id = e.index
				_origin = e.position
				_knob = e.position
				queue_redraw()
		elif _look_id == -1:
			_look_id = e.index
	else:
		if e.index == _joy_id:
			_joy_id = -1
			move = Vector2.ZERO
			queue_redraw()
		elif e.index == _look_id:
			_look_id = -1


func _on_drag(e: InputEventScreenDrag) -> void:
	if e.index == _joy_id:
		var d: Vector2 = e.position - _origin
		if d.length() > JOY_RADIUS:
			d = d.normalized() * JOY_RADIUS
		_knob = _origin + d
		move = d / JOY_RADIUS
		queue_redraw()
	elif e.index == _look_id:
		look_delta += e.relative


func _draw() -> void:
	if _joy_id == -1:
		# عصا باهتة بمكانها الافتراضي لتدل اللاعب
		var size := get_viewport_rect().size
		var c := Vector2(190.0, size.y - 170.0)
		draw_arc(c, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.18), 3.0, true)
		draw_circle(c, KNOB_RADIUS, Color(1, 1, 1, 0.12))
		return
	draw_circle(_origin, JOY_RADIUS, Color(1, 1, 1, 0.10))
	draw_arc(_origin, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0, true)
	draw_circle(_knob, KNOB_RADIUS, Color(1, 1, 1, 0.40))
