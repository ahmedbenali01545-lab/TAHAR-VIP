extends CharacterBody3D
## اللاعب: مشي وجري حسب عصا الحركة + كاميرا من الشخص الثالث

const WALK_MAX := 1.7        # أقصى سرعة مشي (م/ث)
const RUN_MIN := 3.0         # أقل سرعة جري
const RUN_MAX := 4.2         # أقصى سرعة جري
const WALK_ANIM_SPEED := 1.58  # سرعة (م/ث) التي صُمّم عليها أنيميشن walk
const RUN_ANIM_SPEED := 4.0    # سرعة (م/ث) التي صُمّم عليها أنيميشن run
const GRAVITY := 22.0
const ACCEL := 10.0
const TURN_SPEED := 10.0
const LOOK_SENS := 0.0045
const CAM_DISTANCE := 4.8

var touch = null
var limit := 100.0
var walk_check := Callable()
var yaw := 0.0
var pitch := -0.22

var model: Node3D
var anim: AnimationPlayer
var anim_idle := ""
var anim_walk := ""
var anim_run := ""
var pivot: Node3D


func setup(touch_controls, world_limit: float, check: Callable) -> void:
	touch = touch_controls
	limit = world_limit
	walk_check = check


func _ready() -> void:
	floor_snap_length = 0.6
	floor_max_angle = deg_to_rad(55.0)

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.85
	cs.shape = cap
	cs.position = Vector3(0.0, 0.925, 0.0)
	add_child(cs)

	_load_model()
	_build_camera()


func _load_model() -> void:
	var path := ""
	for p in ["res://assets/cowboy.glb", "res://assets/player.glb"]:
		if ResourceLoader.exists(p):
			path = p
			break
	if path != "":
		var scene: PackedScene = load(path)
		model = scene.instantiate()
		add_child(model)
		anim = model.find_child("AnimationPlayer", true, false) as AnimationPlayer
	else:
		push_warning("no character model found, using capsule")
		model = Node3D.new()
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.35
		cm.height = 1.85
		mi.mesh = cm
		mi.position = Vector3(0.0, 0.925, 0.0)
		model.add_child(mi)
		add_child(model)

	if anim:
		print("Player animations: ", anim.get_animation_list())
		for n in anim.get_animation_list():
			var low := String(n).to_lower()
			if low.contains("walk"):
				anim_walk = String(n)
			elif low.contains("run"):
				anim_run = String(n)
			elif low.contains("idle"):
				anim_idle = String(n)
		for n in [anim_idle, anim_walk, anim_run]:
			if n != "":
				anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
		_play(anim_idle, 1.0)


func _build_camera() -> void:
	pivot = Node3D.new()
	pivot.position = Vector3(0.0, 1.65, 0.0)
	add_child(pivot)

	var arm := SpringArm3D.new()
	arm.spring_length = CAM_DISTANCE
	arm.margin = 0.25
	arm.add_excluded_object(get_rid())
	pivot.add_child(arm)

	var cam := Camera3D.new()
	cam.fov = 70.0
	cam.far = 400.0
	arm.add_child(cam)
	cam.make_current()


func _play(anim_name: String, speed: float) -> void:
	if anim == null or anim_name == "":
		return
	anim.speed_scale = speed
	if anim.current_animation != anim_name:
		anim.play(anim_name, 0.25)


func _physics_process(delta: float) -> void:
	# ---- الكاميرا ----
	var look := Vector2.ZERO
	if touch != null:
		look = touch.look_delta
		touch.look_delta = Vector2.ZERO
	yaw -= look.x * LOOK_SENS
	pitch = clampf(pitch - look.y * LOOK_SENS, -1.2, 0.35)
	pivot.rotation = Vector3(pitch, yaw, 0.0)

	# ---- إدخال الحركة (لمس + كيبورد للتجربة: WASD، وShift للجري) ----
	var inp := Vector2.ZERO
	if touch != null:
		inp = touch.move
	var kx := int(Input.is_key_pressed(KEY_D)) - int(Input.is_key_pressed(KEY_A))
	var ky := int(Input.is_key_pressed(KEY_S)) - int(Input.is_key_pressed(KEY_W))
	if kx != 0 or ky != 0:
		var kmag := 1.0 if Input.is_key_pressed(KEY_SHIFT) else 0.5
		inp = Vector2(kx, ky).normalized() * kmag
	var m := minf(inp.length(), 1.0)

	# ---- السرعة: عصا خفيفة = مشي ، عصا كاملة = جري ----
	var speed := 0.0
	if m > 0.08:
		if m < 0.6:
			speed = remap(m, 0.08, 0.6, 0.5, WALK_MAX)
		else:
			speed = remap(m, 0.6, 1.0, RUN_MIN, RUN_MAX)
	var dir := Vector3.ZERO
	if m > 0.08:
		dir = (Basis(Vector3.UP, yaw) * Vector3(inp.x, 0.0, inp.y)).normalized()
	var target := Vector2(dir.x, dir.z) * speed

	var last_pos := position
	var hv := Vector2(velocity.x, velocity.z).move_toward(target, ACCEL * delta)
	velocity.x = hv.x
	velocity.z = hv.y
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	position.x = clampf(position.x, -limit, limit)
	position.z = clampf(position.z, -limit, limit)
	# لا تدخل الماء العميق
	if walk_check.is_valid() and not walk_check.call(position):
		position = last_pos
		velocity.x = 0.0
		velocity.z = 0.0
		hv = Vector2.ZERO

	# ---- اتجاه الشخصية والأنيميشن ----
	var spd := hv.length()
	if spd > 0.2 and model:
		var want := atan2(-hv.x, -hv.y)
		model.rotation.y = lerp_angle(model.rotation.y, want, TURN_SPEED * delta)

	var running := anim != null and anim.current_animation == anim_run
	var run_threshold := 2.2 if running else 2.6
	if spd > run_threshold and anim_run != "":
		_play(anim_run, clampf(spd / RUN_ANIM_SPEED, 0.6, 1.3))
	elif spd > 0.2:
		_play(anim_walk, clampf(spd / WALK_ANIM_SPEED, 0.5, 1.5))
	else:
		_play(anim_idle, 1.0)
