# Forest Walk (Godot 4.7.2)

جزيرة بغابة وشاطئ وبحر. عصا حركة يسار (خفيفة = مشي، كاملة = جري)، سحب يمين للنظر.
على الحاسوب: WASD (+ Shift للجري) وسحب الماوس.

## ملفات المجسمات (assets/)
cowboy.glb, pine_tree.glb, oak_tree.glb, rock_1-3.glb, bush.glb, grass.glb, log.glb
palm.glb (اختياري: لو غير موجود تُتجاهل النخيل)

## الأداء
في scripts/main.gd: SHADOWS ، GRASS_DENSITY

## البناء
ارفع المشروع إلى GitHub (فرع main) وسيُبنى الـ APK من تبويب Actions (Artifacts → forest-walk-apk).
