# DZ T AI

موقع دردشة بالذكاء الاصطناعي بنفس واجهة use.ai (عربي RTL) مع نافذة جلسات قديمة
تفتح من زر الثلاث شرطات (☰) أعلى الصفحة.

## التشغيل على الـ VPS

```bash
cd dzt-ai
pip install -r requirements.txt
python server.py            # يعمل على http://IP:8080
```

تشغيل دائم في الخلفية:

```bash
nohup python server.py > out.log 2>&1 &
# أو:  screen -dmS dzt python server.py
```

تغيير المنفذ: `PORT=80 python server.py`
وضع تجريبي بدون الاتصال بالـ API: `DZT_MOCK=1 python server.py`
لوجس مفصلة للطلبات والردود: `DEBUG=1 python server.py` (الملف `server.log`)

## الملفات

| الملف | الوظيفة |
|---|---|
| `config.py` | التوكنات والمعرفات (منسوخة حرفياً من main.py) + قائمة النماذج الأربعة |
| `server.py` | الخادم: `/api/chat` (بث SSE) و `/api/models` و `/api/delete` + تقديم الواجهة |
| `static/index.html` | هيكل الصفحة |
| `static/style.css` | التصميم (فاتح/داكن) |
| `static/app.js` | الدردشة، الجلسات، الماركداون، القوائم |

## النماذج (في config.py)

`gpt6_1_sol_thinking` (الافتراضي) · `claude55sonnetthinking` · `gemini4argonthinking` · `grok47thinking`

لتغيير نموذج أو إضافته عدّل القائمة `MODELS` في `config.py` ثم أعد تشغيل الخادم.
الخادم يرفض أي نموذج غير موجود في هذه القائمة.

## كيف تعمل الجلسات

- المحادثات تُحفظ في متصفح كل مستخدم (localStorage) ولا يخزّنها الخادم.
- حالة المحادثة على الـ API (thread) تُحفظ مع كل جلسة وتُرسل مع كل رسالة للمتابعة.
- حذف جلسة من النافذة يحذفها أيضاً من سيرفر الـ API.

## خلف nginx (اختياري)

```nginx
location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_http_version 1.1;
    proxy_buffering off;
    proxy_read_timeout 600s;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $remote_addr;
}
```
وشغّل الخادم مع `TRUST_PROXY=1`.
