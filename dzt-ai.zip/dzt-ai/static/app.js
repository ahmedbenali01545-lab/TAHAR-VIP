/* =====================================================================
   DZ T AI — منطق الواجهة
   - الجلسات تُحفظ في متصفح المستخدم (localStorage)
   - الخادم لا يخزّن شيئاً؛ حالة المحادثة (thread) تُرسل مع كل طلب
   ===================================================================== */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const LS = { sessions: 'dzt.sessions.v1', model: 'dzt.model', theme: 'dzt.theme' };
  const TOUCH = matchMedia('(pointer: coarse)').matches;
  const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const MAX_FILE = 200 * 1024;

  const FALLBACK_MODELS = [
    { key: 'gpt6_1_sol_thinking', label: 'GPT-6.1 Sol Thinking', provider: 'OpenAI' },
    { key: 'claude55sonnetthinking', label: 'Claude Sonnet 5.5 Thinking', provider: 'Anthropic' },
    { key: 'gemini4argonthinking', label: 'Gemini 4 Argon Thinking', provider: 'Google' },
    { key: 'grok47thinking', label: 'Grok 4.7 Thinking', provider: 'xAI' },
  ];

  const svg = (d, { w = 18, sw = 1.8, fill = 'none' } = {}) =>
    `<svg viewBox="0 0 24 24" width="${w}" height="${w}" fill="${fill}" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const ICON = {
    arrowUp: svg('<path d="M12 19V5M5 12l7-7 7 7"/>', { sw: 2.2 }),
    stop: `<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="5" y="5" width="14" height="14" rx="3"/></svg>`,
    copy: svg('<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>', { w: 16 }),
    check: svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>', { w: 16, sw: 2.2 }),
    pencil: svg('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>', { w: 16 }),
    trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>', { w: 16 }),
    file: svg('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>', { w: 14 }),
  };

  /* ---------- عناصر الصفحة ---------- */
  const el = {
    app: $('#app'), messages: $('#messages'), input: $('#input'), composer: $('#composer'),
    send: $('#sendBtn'), mic: $('#micBtn'),
    attach: $('#attach'), attachName: $('#attachName'), attachRemove: $('#attachRemove'),
    fileInput: $('#fileInput'), attachBtn: $('#attachBtn'),
    plusBtn: $('#plusBtn'), plusMenu: $('#plusMenu'), newFromPlus: $('#newFromPlus'),
    modelBtn: $('#modelBtn'), modelMenu: $('#modelMenu'), modelLabel: $('#modelLabel'),
    moreBtn: $('#moreBtn'), moreMenu: $('#moreMenu'), themeBtn: $('#themeBtn'), clearAllMenuBtn: $('#clearAllMenuBtn'),
    menuBtn: $('#menuBtn'), drawer: $('#drawer'), drawerClose: $('#drawerClose'), scrim: $('#scrim'),
    newChatBtn: $('#newChatBtn'), searchInput: $('#searchInput'), sessionList: $('#sessionList'), clearAllBtn: $('#clearAllBtn'),
    brand: $('#brand'), newBtnTop: $('#newBtnTop'), loginBtn: $('#loginBtn'), pricingBtn: $('#pricingBtn'),
    toast: $('#toast'), dlg: $('#confirmDlg'), dlgMsg: $('#confirmMsg'), dlgOk: $('#confirmOk'),
  };

  /* ---------- الحالة ---------- */
  const state = {
    sessions: [],
    activeId: null,           // null = محادثة جديدة (لم تُنشأ بعد)
    models: FALLBACK_MODELS,
    model: FALLBACK_MODELS[0].key,
    inflight: new Map(),      // sessionId -> { ac, start }
    errors: new Map(),        // sessionId -> نص الخطأ
    attach: null,             // { name, content }
    stick: true,
    stopReveal: null,
  };

  /* =====================================================================
                              أدوات عامة
     ===================================================================== */
  const now = () => Date.now();
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${now()}-${Math.random().toString(16).slice(2)}`);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let toastTimer = null;
  function toast(msg) {
    el.toast.textContent = msg;
    el.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.remove('show'), 2400);
  }

  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); return true; }
    catch {
      const ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
      document.body.appendChild(ta); ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { /* ignore */ }
      ta.remove();
      return ok;
    }
  }

  function confirmBox(msg, okLabel = 'تأكيد') {
    return new Promise((resolve) => {
      el.dlgMsg.textContent = msg;
      el.dlgOk.textContent = okLabel;
      el.dlg.returnValue = 'cancel';
      const onClose = () => { el.dlg.removeEventListener('close', onClose); resolve(el.dlg.returnValue === 'ok'); };
      el.dlg.addEventListener('close', onClose);
      el.dlg.showModal();
    });
  }

  /* =====================================================================
                              ماركداون
     ===================================================================== */
  const LIST_RE = /^(\s*)([-*+]|\d{1,3}[.)])\s+(.*)$/;
  const HR_RE = /^\s*([-*_])(\s*\1){2,}\s*$/;
  const SEP_RE = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;

  function inline(t) {
    const codes = [];
    t = t.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
    t = esc(t);
    t = t.replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[\s(])\*([^*\s][^*\n]*?)\*(?=[\s).,!?:;،؟]|$)/g, '$1<em>$2</em>');
    t = t.replace(/~~([^~\n]+)~~/g, '<del>$1</del>');
    t = t.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    t = t.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[+i])}</code>`);
    return t;
  }

  function codeBlock(code, lang) {
    return `<div class="code" dir="ltr"><div class="code-head"><span>${esc(lang || 'code')}</span>` +
      `<button class="copy-code" type="button" aria-label="نسخ الكود">نسخ</button></div>` +
      `<pre><code>${esc(code)}</code></pre></div>`;
  }

  function splitRow(r) {
    r = r.trim();
    if (r.startsWith('|')) r = r.slice(1);
    if (r.endsWith('|')) r = r.slice(0, -1);
    return r.split('|').map((c) => c.trim());
  }

  function parseList(lines, i) {
    const first = lines[i].match(LIST_RE);
    const base = first[1].length;
    const ordered = /\d/.test(first[2]);
    const tag = ordered ? 'ol' : 'ul';
    let html = `<${tag}>`;
    while (i < lines.length) {
      const m = lines[i].match(LIST_RE);
      if (!m || m[1].length < base) break;
      if (m[1].length > base) {
        const r = parseList(lines, i);
        html = html.replace(/<\/li>$/, '') + r.html + '</li>';
        i = r.i;
        continue;
      }
      html += `<li dir="auto">${inline(m[3])}</li>`;
      i++;
      while (i < lines.length && lines[i].trim() && !LIST_RE.test(lines[i]) && /^\s{2,}\S/.test(lines[i])) {
        html = html.replace(/<\/li>$/, `<br>${inline(lines[i].trim())}</li>`);
        i++;
      }
      let j = i;
      while (j < lines.length && !lines[j].trim()) j++;
      if (j > i && j < lines.length && LIST_RE.test(lines[j]) && lines[j].match(/^\s*/)[0].length >= base) i = j;
    }
    return { html: html + `</${tag}>`, i };
  }

  function md(src) {
    const lines = String(src).replace(/\r\n?/g, '\n').split('\n');
    const startsBlock = (l, next) =>
      /^\s*```/.test(l) || /^#{1,6}\s+/.test(l) || /^\s*>/.test(l) || HR_RE.test(l) || LIST_RE.test(l) ||
      (l.includes('|') && next !== undefined && SEP_RE.test(next));
    let html = '';
    let i = 0;
    while (i < lines.length) {
      const l = lines[i];
      let m = l.match(/^\s*```\s*([\w+#.-]*)\s*$/);
      if (m) {
        const buf = [];
        i++;
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
        i++;
        html += codeBlock(buf.join('\n'), m[1]);
        continue;
      }
      if (!l.trim()) { i++; continue; }
      m = l.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/);
      if (m) {
        const h = Math.min(4, Math.max(2, m[1].length + 1));
        html += `<h${h} dir="auto">${inline(m[2])}</h${h}>`;
        i++;
        continue;
      }
      if (HR_RE.test(l)) { html += '<hr>'; i++; continue; }
      if (/^\s*>/.test(l)) {
        const buf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { buf.push(lines[i].replace(/^\s*>\s?/, '')); i++; }
        html += `<blockquote dir="auto">${md(buf.join('\n'))}</blockquote>`;
        continue;
      }
      if (LIST_RE.test(l)) {
        const r = parseList(lines, i);
        html += r.html;
        i = r.i;
        continue;
      }
      if (l.includes('|') && i + 1 < lines.length && SEP_RE.test(lines[i + 1])) {
        const head = splitRow(l);
        const aligns = splitRow(lines[i + 1]).map((c) => (/^:-+:$/.test(c) ? 'center' : /-:$/.test(c) ? 'right' : /^:-/.test(c) ? 'left' : ''));
        i += 2;
        let t = '<div class="table-wrap"><table><thead><tr>' +
          head.map((c, k) => `<th dir="auto"${aligns[k] ? ` style="text-align:${aligns[k]}"` : ''}>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
        while (i < lines.length && lines[i].trim() && lines[i].includes('|')) {
          const cells = splitRow(lines[i]);
          t += '<tr>' + head.map((_, k) => `<td dir="auto"${aligns[k] ? ` style="text-align:${aligns[k]}"` : ''}>${inline(cells[k] || '')}</td>`).join('') + '</tr>';
          i++;
        }
        html += t + '</tbody></table></div>';
        continue;
      }
      const buf = [l];
      i++;
      while (i < lines.length && lines[i].trim() && !startsBlock(lines[i], lines[i + 1])) { buf.push(lines[i]); i++; }
      html += `<p dir="auto">${buf.map(inline).join('<br>')}</p>`;
    }
    return html;
  }

  /* =====================================================================
                              الجلسات (التخزين)
     ===================================================================== */
  function loadSessions() {
    try {
      const v = JSON.parse(localStorage.getItem(LS.sessions) || '[]');
      return Array.isArray(v) ? v.filter((s) => s && s.id && Array.isArray(s.messages)) : [];
    } catch { return []; }
  }

  function persist() {
    try {
      const data = state.sessions.map((s) => ({ ...s, messages: s.messages.filter((m) => !m.transient) }));
      localStorage.setItem(LS.sessions, JSON.stringify(data));
    } catch { toast('تعذّر حفظ المحادثات: مساحة المتصفح ممتلئة.'); }
  }

  const getSession = (id) => state.sessions.find((s) => s.id === id);
  const activeSession = () => (state.activeId ? getSession(state.activeId) : null);
  const sortSessions = () => state.sessions.sort((a, b) => b.updated - a.updated);

  function makeTitle(text) {
    const t = String(text || '').replace(/\s+/g, ' ').trim();
    return t.length > 48 ? t.slice(0, 48) + '…' : (t || 'محادثة جديدة');
  }

  function modelLabel(key) {
    const m = state.models.find((x) => x.key === key);
    return m ? m.label : key;
  }

  /* =====================================================================
                              عرض المحادثة
     ===================================================================== */
  function setMode(mode) { el.app.dataset.mode = mode; }

  function scrollBottom(force) {
    if (force || state.stick) el.messages.scrollTop = el.messages.scrollHeight;
  }
  el.messages.addEventListener('scroll', () => {
    const m = el.messages;
    state.stick = m.scrollHeight - m.scrollTop - m.clientHeight < 90;
  }, { passive: true });

  function cancelReveal() {
    if (state.stopReveal) { state.stopReveal(); state.stopReveal = null; }
  }

  function buildUser(m) {
    const d = document.createElement('div');
    d.className = 'msg user';
    const chip = m.file ? `<div class="file-chip">${ICON.file}<span>${esc(m.file)}</span></div>` : '';
    d.innerHTML = `<div class="bubble" dir="auto">${chip}${esc(m.content)}</div>`;
    return d;
  }

  function buildAssistant(m, animate) {
    const d = document.createElement('div');
    d.className = 'msg ai';
    d.innerHTML = '<div class="content"></div>' +
      '<div class="msg-foot"><button class="icon-btn" type="button" data-copy aria-label="نسخ الرد" title="نسخ">' + ICON.copy + '</button>' +
      `<span class="model-tag">${esc(m.model || '')}</span></div>` +
      (m.note ? `<div class="msg-note">${esc(m.note)}</div>` : '');
    const content = d.querySelector('.content');
    const foot = d.querySelector('.msg-foot');
    const full = m.content || '';
    if (!animate || REDUCED || document.hidden || full.length < 40) {
      content.innerHTML = md(full);
      return d;
    }
    foot.hidden = true;
    let n = 0;
    const step = Math.max(8, Math.ceil(full.length / 60));
    const timer = setInterval(() => {
      n = Math.min(full.length, n + step);
      content.innerHTML = md(full.slice(0, n));
      scrollBottom();
      if (n >= full.length) { clearInterval(timer); state.stopReveal = null; foot.hidden = false; }
    }, 28);
    state.stopReveal = () => { clearInterval(timer); content.innerHTML = md(full); foot.hidden = false; };
    return d;
  }

  function buildThinking(start) {
    const d = document.createElement('div');
    d.className = 'msg ai thinking-msg';
    d.innerHTML = `<div class="thinking"><span class="dots"><i></i><i></i><i></i></span><span class="t-label" data-start="${start}">يفكّر…</span></div>`;
    return d;
  }

  function buildError(msg) {
    const d = document.createElement('div');
    d.className = 'msg ai';
    d.innerHTML = `<div class="err" role="alert"><span>${esc(msg)}</span><button class="btn-ghost" type="button" data-retry>إعادة المحاولة</button></div>`;
    return d;
  }

  function renderMessages() {
    cancelReveal();
    el.messages.textContent = '';
    const s = activeSession();
    if (!s) { setMode('home'); updateSendButton(); return; }
    setMode(s.messages.length || state.inflight.has(s.id) ? 'chat' : 'home');
    for (const m of s.messages) el.messages.appendChild(m.role === 'user' ? buildUser(m) : buildAssistant(m, false));
    const run = state.inflight.get(s.id);
    if (run) el.messages.appendChild(buildThinking(run.start));
    else if (state.errors.has(s.id)) el.messages.appendChild(buildError(state.errors.get(s.id)));
    state.stick = true;
    scrollBottom(true);
    updateSendButton();
  }

  // عدّاد زمن التفكير
  setInterval(() => {
    document.querySelectorAll('.t-label[data-start]').forEach((n) => {
      const sec = Math.max(0, Math.floor((now() - Number(n.dataset.start)) / 1000));
      n.textContent = sec < 3 ? 'يفكّر…' : `يفكّر… ${sec} ث`;
    });
  }, 1000);

  /* =====================================================================
                              الإرسال
     ===================================================================== */
  function updateSendButton() {
    const s = activeSession();
    const busy = !!(s && state.inflight.has(s.id));
    if (busy) {
      el.send.dataset.state = 'stop';
      el.send.disabled = false;
      el.send.innerHTML = ICON.stop;
      el.send.setAttribute('aria-label', 'إيقاف الرد');
    } else {
      el.send.dataset.state = 'send';
      el.send.innerHTML = ICON.arrowUp;
      el.send.setAttribute('aria-label', 'إرسال');
      el.send.disabled = !(el.input.value.trim() || state.attach);
    }
  }

  function autosize() {
    el.input.style.height = 'auto';
    el.input.style.height = Math.min(el.input.scrollHeight, 200) + 'px';
  }

  function composeQuery(text, file) {
    return `${text || 'حلّل هذا الملف وأخبرني بما فيه.'}\n\n[الملف: ${file.name}]\n\`\`\`\n${file.content}\n\`\`\``;
  }

  async function streamChat(payload, signal) {
    let resp;
    try {
      resp = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload), signal,
      });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      throw new Error('تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم حاول مرة أخرى.');
    }
    if (!resp.ok) {
      let msg = 'تعذّر إرسال الطلب.';
      try { const j = await resp.json(); if (j && j.message) msg = j.message; } catch { /* ignore */ }
      throw new Error(msg);
    }
    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let result = null;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const line = chunk.split('\n').find((l) => l.startsWith('data:'));
        if (line) { try { result = JSON.parse(line.slice(5).trim()); } catch { /* ignore */ } }
      }
    }
    if (!result) throw new Error('انقطع الاتصال قبل وصول الرد. حاول مرة أخرى.');
    if (result.type === 'error') throw new Error(result.message || 'حدث خطأ.');
    return result;
  }

  async function doSend({ text = '', file = null, retry = false } = {}) {
    let sess = activeSession();
    if (sess && state.inflight.has(sess.id)) return;

    if (!retry) {
      if (!sess) {
        sess = { id: uid(), title: makeTitle(text || (file && file.name)), created: now(), updated: now(), thread: null, messages: [] };
        state.sessions.unshift(sess);
        state.activeId = sess.id;
      }
      const um = { role: 'user', content: text, ts: now() };
      if (file) { um.file = file.name; um.query = composeQuery(text, file); }
      sess.messages.push(um);
      sess.updated = now();
      el.input.value = '';
      state.attach = null;
      el.attach.hidden = true;
      autosize();
    }
    if (!sess) return;

    const lastUser = [...sess.messages].reverse().find((m) => m.role === 'user');
    if (!lastUser) return;
    const query = lastUser.query || lastUser.content;
    const modelKey = state.model;

    state.errors.delete(sess.id);
    const run = { ac: new AbortController(), start: now() };
    state.inflight.set(sess.id, run);
    sortSessions();
    persist();
    renderMessages();
    scrollBottom(true);

    let result = null;
    let errMsg = null;
    try {
      result = await streamChat({ query, model: modelKey, thread: sess.thread }, run.ac.signal);
    } catch (e) {
      errMsg = e.name === 'AbortError' ? 'تم إيقاف الرد.' : (e.message || 'حدث خطأ غير متوقع.');
    }
    state.inflight.delete(sess.id);

    if (errMsg) {
      if (getSession(sess.id)) {
        state.errors.set(sess.id, errMsg);
        if (state.activeId === sess.id) renderMessages();
      }
      updateSendButton();
      return;
    }
    if (!getSession(sess.id)) return; // حُذفت الجلسة أثناء الانتظار

    sess.thread = result.thread || sess.thread;
    let content = (result.text || '').trim();
    if (!content && Array.isArray(result.urls) && result.urls.length) content = result.urls.map((u) => `- [${u}](${u})`).join('\n');
    const am = { role: 'assistant', content: content || '(رد فارغ)', model: modelLabel(modelKey), ts: now() };
    if (result.restarted) am.note = 'لم تنجح متابعة المحادثة على الخادم، فبدأتُ محادثة جديدة (قد لا يتذكّر النموذج الرسائل السابقة).';
    sess.messages.push(am);
    sess.updated = now();
    sortSessions();
    persist();
    if (el.drawer.getAttribute('aria-hidden') === 'false') renderDrawer();

    if (state.activeId === sess.id) {
      const thinking = el.messages.querySelector('.thinking-msg');
      if (thinking) thinking.remove();
      el.messages.appendChild(buildAssistant(am, true));
      scrollBottom();
    }
    updateSendButton();
  }

  function stopCurrent() {
    const s = activeSession();
    const run = s && state.inflight.get(s.id);
    if (run) run.ac.abort();
  }

  el.composer.addEventListener('submit', (e) => {
    e.preventDefault();
    if (el.send.dataset.state === 'stop') { stopCurrent(); return; }
    const text = el.input.value.trim();
    if (!text && !state.attach) return;
    doSend({ text, file: state.attach });
  });

  el.input.addEventListener('input', () => { autosize(); updateSendButton(); });
  el.input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !TOUCH) {
      e.preventDefault();
      el.composer.requestSubmit();
    }
  });

  el.messages.addEventListener('click', async (e) => {
    const retry = e.target.closest('[data-retry]');
    if (retry) { doSend({ retry: true }); return; }
    const cc = e.target.closest('.copy-code');
    if (cc) {
      const code = cc.closest('.code').querySelector('code').textContent;
      if (await copyText(code)) { cc.textContent = 'تم النسخ'; setTimeout(() => { cc.textContent = 'نسخ'; }, 1500); }
      return;
    }
    const cm = e.target.closest('[data-copy]');
    if (cm) {
      const idx = [...el.messages.querySelectorAll('.msg.ai:not(.thinking-msg)')].indexOf(cm.closest('.msg'));
      const s = activeSession();
      const aiMsgs = s ? s.messages.filter((m) => m.role === 'assistant') : [];
      const m = aiMsgs[idx];
      if (m && await copyText(m.content)) {
        cm.innerHTML = ICON.check;
        setTimeout(() => { cm.innerHTML = ICON.copy; }, 1500);
      }
    }
  });

  /* =====================================================================
                    الملفات + الإدخال الصوتي
     ===================================================================== */
  el.attachBtn.addEventListener('click', () => { closePopovers(); el.fileInput.click(); });
  el.fileInput.addEventListener('change', () => {
    const f = el.fileInput.files && el.fileInput.files[0];
    el.fileInput.value = '';
    if (!f) return;
    if (f.size > MAX_FILE) { toast('الملف كبير. الحد الأقصى 200 كيلوبايت.'); return; }
    const r = new FileReader();
    r.onload = () => {
      const content = String(r.result || '');
      if (content.includes('\u0000')) { toast('هذا الملف ليس نصياً.'); return; }
      state.attach = { name: f.name, content };
      el.attachName.textContent = f.name;
      el.attach.hidden = false;
      updateSendButton();
      el.input.focus();
    };
    r.onerror = () => toast('تعذّرت قراءة الملف.');
    r.readAsText(f);
  });
  el.attachRemove.addEventListener('click', () => { state.attach = null; el.attach.hidden = true; updateSendButton(); });

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null;
  el.mic.addEventListener('click', () => {
    if (!SR) { toast('الإدخال الصوتي غير مدعوم في هذا المتصفح.'); return; }
    if (rec) { rec.stop(); return; }
    rec = new SR();
    rec.lang = 'ar-DZ';
    rec.interimResults = true;
    rec.continuous = false;
    const base = el.input.value;
    rec.onresult = (ev) => {
      let t = '';
      for (const r of ev.results) t += r[0].transcript;
      el.input.value = (base ? base + ' ' : '') + t;
      autosize(); updateSendButton();
    };
    rec.onerror = (ev) => toast(ev.error === 'not-allowed' ? 'اسمح للموقع باستخدام الميكروفون.' : 'تعذّر الإدخال الصوتي.');
    rec.onend = () => { rec = null; el.mic.classList.remove('listening'); };
    el.mic.classList.add('listening');
    try { rec.start(); } catch { rec = null; el.mic.classList.remove('listening'); }
  });

  /* =====================================================================
                    القوائم المنبثقة (+ / النموذج / المزيد)
     ===================================================================== */
  const pops = [
    { btn: el.plusBtn, menu: el.plusMenu },
    { btn: el.modelBtn, menu: el.modelMenu },
    { btn: el.moreBtn, menu: el.moreMenu },
  ];
  function closePopovers(except) {
    for (const p of pops) {
      if (p === except) continue;
      p.menu.hidden = true;
      p.btn.setAttribute('aria-expanded', 'false');
    }
  }
  for (const p of pops) {
    p.btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = p.menu.hidden;
      closePopovers(p);
      p.menu.hidden = !open;
      p.btn.setAttribute('aria-expanded', String(open));
      if (open) { const first = p.menu.querySelector('button'); if (first && !TOUCH) first.focus(); }
    });
  }
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.menu-wrap')) closePopovers();
  });

  function renderModelMenu() {
    el.modelMenu.innerHTML = state.models.map((m) =>
      `<button type="button" role="option" class="model-opt" data-key="${esc(m.key)}" aria-selected="${m.key === state.model}">` +
      `<span class="mo-text"><span class="mo-label" dir="ltr">${esc(m.label)}</span><span class="mo-prov" dir="ltr">${esc(m.provider)}</span></span>` +
      (m.key === state.model ? svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>', { w: 17, sw: 2.2 }) : '') + '</button>').join('');
    el.modelLabel.textContent = modelLabel(state.model);
  }
  el.modelMenu.addEventListener('click', (e) => {
    const b = e.target.closest('.model-opt');
    if (!b) return;
    state.model = b.dataset.key;
    try { localStorage.setItem(LS.model, state.model); } catch { /* ignore */ }
    renderModelMenu();
    closePopovers();
    el.input.focus();
  });

  /* ---------- الثيم ---------- */
  function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t === 'dark' ? '#141312' : '#fafaf9');
    el.themeBtn.textContent = t === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن';
    try { localStorage.setItem(LS.theme, t); } catch { /* ignore */ }
  }
  el.themeBtn.addEventListener('click', () => {
    applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    closePopovers();
  });

  /* =====================================================================
                    نافذة الجلسات القديمة (الثلاث شرطات)
     ===================================================================== */
  function groupOf(ts) {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    const day = 86400000;
    const t0 = d.getTime();
    if (ts >= t0) return 'اليوم';
    if (ts >= t0 - day) return 'أمس';
    if (ts >= t0 - 6 * day) return 'آخر 7 أيام';
    if (ts >= t0 - 29 * day) return 'آخر 30 يوماً';
    return 'أقدم';
  }

  function renderDrawer() {
    const q = el.searchInput.value.trim().toLowerCase();
    const list = state.sessions.filter((s) =>
      !q || s.title.toLowerCase().includes(q) || s.messages.some((m) => (m.content || '').toLowerCase().includes(q)));
    if (!list.length) {
      el.sessionList.innerHTML = q
        ? `<div class="dr-empty">لا توجد نتائج لـ «${esc(el.searchInput.value.trim())}».</div>`
        : '<div class="dr-empty">لا توجد محادثات بعد.<br>اطرح سؤالك الأول وستظهر هنا.</div>';
      return;
    }
    let html = '';
    let last = '';
    for (const s of list) {
      const g = groupOf(s.updated);
      if (g !== last) { html += `<div class="dr-group" role="presentation">${g}</div>`; last = g; }
      const busy = state.inflight.has(s.id);
      html += `<div class="s-item${s.id === state.activeId ? ' is-active' : ''}" role="listitem" data-id="${esc(s.id)}">` +
        `<button class="s-open" type="button" data-act="open" title="${esc(s.title)}"${s.id === state.activeId ? ' aria-current="true"' : ''}>${busy ? '… ' : ''}${esc(s.title)}</button>` +
        `<div class="s-actions"><button type="button" data-act="rename" aria-label="إعادة التسمية" title="إعادة التسمية">${ICON.pencil}</button>` +
        `<button type="button" data-act="delete" aria-label="حذف المحادثة" title="حذف">${ICON.trash}</button></div></div>`;
    }
    el.sessionList.innerHTML = html;
  }

  function openDrawer() {
    closePopovers();
    renderDrawer();
    document.body.classList.add('drawer-open');
    el.drawer.setAttribute('aria-hidden', 'false');
    el.menuBtn.setAttribute('aria-expanded', 'true');
    el.app.inert = true;
    setTimeout(() => el.newChatBtn.focus(), 40);
  }
  function closeDrawer(returnFocus = true) {
    if (el.drawer.getAttribute('aria-hidden') === 'true') return;
    document.body.classList.remove('drawer-open');
    el.drawer.setAttribute('aria-hidden', 'true');
    el.menuBtn.setAttribute('aria-expanded', 'false');
    el.app.inert = false;
    if (returnFocus) el.menuBtn.focus();
  }

  el.menuBtn.addEventListener('click', () => (el.drawer.getAttribute('aria-hidden') === 'false' ? closeDrawer() : openDrawer()));
  el.drawerClose.addEventListener('click', () => closeDrawer());
  el.scrim.addEventListener('click', () => closeDrawer());
  el.searchInput.addEventListener('input', renderDrawer);

  el.drawer.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    const f = [...el.drawer.querySelectorAll('button, input')].filter((n) => !n.disabled && n.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });

  function newChat() {
    cancelReveal();
    state.activeId = null;
    state.stick = true;
    renderMessages();
    closeDrawer(false);
    if (!TOUCH) el.input.focus();
  }
  function openSession(id) {
    if (!getSession(id)) return;
    state.activeId = id;
    renderMessages();
    closeDrawer(false);
    if (!TOUCH) el.input.focus();
  }

  function remoteDelete(s) {
    const t = s.thread;
    if (t && t.context_uuid && t.rw_token) {
      fetch('/api/delete', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context_uuid: t.context_uuid, rw_token: t.rw_token }),
      }).catch(() => {});
    }
  }

  async function deleteSession(id) {
    const s = getSession(id);
    if (!s) return;
    if (!(await confirmBox(`حذف المحادثة «${s.title}»؟ لا يمكن التراجع عن ذلك.`, 'حذف'))) return;
    const run = state.inflight.get(id);
    if (run) run.ac.abort();
    state.inflight.delete(id);
    state.errors.delete(id);
    state.sessions = state.sessions.filter((x) => x.id !== id);
    remoteDelete(s);
    if (state.activeId === id) state.activeId = null;
    persist();
    renderDrawer();
    renderMessages();
  }

  async function clearAll() {
    if (!state.sessions.length) { toast('لا توجد محادثات لحذفها.'); return; }
    if (!(await confirmBox('حذف كل المحادثات؟ لا يمكن التراجع عن ذلك.', 'حذف الكل'))) return;
    for (const run of state.inflight.values()) run.ac.abort();
    state.inflight.clear();
    state.errors.clear();
    state.sessions.forEach(remoteDelete);
    state.sessions = [];
    state.activeId = null;
    persist();
    renderDrawer();
    renderMessages();
    toast('تم حذف كل المحادثات.');
  }

  function startRename(item) {
    const id = item.dataset.id;
    const s = getSession(id);
    if (!s) return;
    const btn = item.querySelector('.s-open');
    const input = document.createElement('input');
    input.className = 's-rename';
    input.value = s.title;
    input.maxLength = 80;
    input.setAttribute('aria-label', 'اسم المحادثة');
    btn.replaceWith(input);
    item.querySelector('.s-actions').style.display = 'none';
    input.focus();
    input.select();
    let done = false;
    const finish = (save) => {
      if (done) return;
      done = true;
      if (save) {
        const v = input.value.replace(/\s+/g, ' ').trim();
        if (v) { s.title = v; persist(); }
      }
      renderDrawer();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
  }

  el.sessionList.addEventListener('click', (e) => {
    const item = e.target.closest('.s-item');
    const act = e.target.closest('[data-act]');
    if (!item || !act) return;
    const id = item.dataset.id;
    if (act.dataset.act === 'open') openSession(id);
    else if (act.dataset.act === 'rename') startRename(item);
    else if (act.dataset.act === 'delete') deleteSession(id);
  });

  el.newChatBtn.addEventListener('click', newChat);
  el.clearAllBtn.addEventListener('click', clearAll);
  el.clearAllMenuBtn.addEventListener('click', () => { closePopovers(); clearAll(); });

  /* ---------- الشريط العلوي ---------- */
  el.brand.addEventListener('click', (e) => { e.preventDefault(); newChat(); });
  el.newBtnTop.addEventListener('click', newChat);
  el.newFromPlus.addEventListener('click', () => { closePopovers(); newChat(); });
  el.loginBtn.addEventListener('click', () => toast('تسجيل الدخول قريباً.'));
  el.pricingBtn.addEventListener('click', () => toast('صفحة الأسعار قريباً.'));
  document.querySelectorAll('.pill').forEach((p) => p.addEventListener('click', () => {
    const k = p.dataset.nav;
    if (k === 'chat') newChat();
    else if (k === 'library') openDrawer();
    else toast(k === 'images' ? 'قسم الصور قريباً.' : 'قسم التطبيقات قريباً.');
  }));

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (el.dlg.open) return;
    const anyPop = pops.some((p) => !p.menu.hidden);
    if (anyPop) { closePopovers(); return; }
    closeDrawer();
  });

  /* =====================================================================
                              الإقلاع
     ===================================================================== */
  async function init() {
    applyTheme(document.documentElement.getAttribute('data-theme') || 'light');
    state.sessions = loadSessions();
    sortSessions();

    try {
      const r = await fetch('/api/models');
      const j = await r.json();
      if (j && Array.isArray(j.models) && j.models.length) {
        state.models = j.models;
        state.model = j.default || j.models[0].key;
      }
    } catch { /* نستعمل القائمة الافتراضية */ }
    let saved = null;
    try { saved = localStorage.getItem(LS.model); } catch { /* ignore */ }
    if (saved && state.models.some((m) => m.key === saved)) state.model = saved;

    renderModelMenu();
    renderMessages();
    updateSendButton();
    if (!TOUCH) el.input.focus();
  }
  init();
})();
