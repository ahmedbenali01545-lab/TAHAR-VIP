#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DZ T AI — خادم الموقع
---------------------
تشغيل:   python server.py          (ثم افتح  http://IP:8080 )
متغيرات اختيارية:
    PORT=8080   HOST=0.0.0.0
    DZT_MOCK=1            وضع تجريبي (ردود وهمية بدون الاتصال بالـ API)
    RATE_LIMIT_PER_MIN=30 حد الطلبات لكل IP في الدقيقة (0 = بدون حد)
    TRUST_PROXY=1         استعمل X-Forwarded-For (عند الوضع خلف nginx)
    DEBUG=1               لوجس مفصلة للطلبات والردود
المكتبة الوحيدة المطلوبة:  httpx[http2]   (و curl_cffi اختياري)
"""
import json
import logging
import mimetypes
import os
import re
import sys
import threading
import time
import uuid
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.parse import unquote, urlparse

import config as C

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8080"))
MOCK = os.getenv("DZT_MOCK", "0") == "1"
DEBUG = os.getenv("DEBUG", "0") == "1"
RATE = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
TRUST_PROXY = os.getenv("TRUST_PROXY", "0") == "1"
LOG_BODY_LIMIT = int(os.getenv("LOG_BODY_LIMIT", "3000"))
MAX_QUERY = 30000
STATIC = (Path(__file__).parent / "static").resolve()
MODEL_BY_KEY = {m["key"]: m for m in C.MODELS}

log = logging.getLogger("dzt")


def setup_logging():
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s", "%H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    fh = RotatingFileHandler("server.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(sh)
    root.addHandler(fh)
    for noisy in ("httpx", "httpcore", "hpack", "h2", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    log.setLevel(logging.DEBUG if DEBUG else logging.INFO)


def clip(obj, n=None):
    n = LOG_BODY_LIMIT if n is None else n
    s = obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False)
    return s if not n or len(s) <= n else s[:n] + f"... [+{len(s) - n} chars]"


def mask_headers(h):
    out = {}
    for k, v in h.items():
        if k.lower() == "authorization" and len(v) > 30:
            v = v[:18] + "…" + v[-6:]
        out[k] = v
    return out


# =====================================================================
#                     الاتصال بالـ API (HTTP)
# =====================================================================
def hdrs(sse=False):
    h = {
        "authorization": f"Bearer {C.PPLX_TOKEN}",
        "user-agent": C.USER_AGENT,
        "x-app-version": C.APP_VERSION,
        "x-client-version": C.APP_VERSION,
        "x-client-name": "Perplexity-Android",
        "x-client-env": "prod",
        "x-app-apiclient": "android",
        "x-app-apiversion": "2.17",
        "accept-language": C.LANGUAGE,
        "x-device-id": f"android:{C.DEVICE_ID}",
        "content-type": "application/json; charset=utf-8",
    }
    if sse:
        h["accept"] = "text/event-stream"
    return h


def _t_httpx(method, url, headers, body):
    import httpx  # استيراد متأخر
    with httpx.Client(http2=True, timeout=httpx.Timeout(30.0, read=300.0)) as c:
        r = c.request(method, url, headers=headers, json=body)
        return r.status_code, dict(r.headers), r.content.decode("utf-8", "replace")


def _t_curl(method, url, headers, body):
    from curl_cffi import requests as creq  # ImportError لو غير مثبت
    r = creq.request(method, url, headers=headers, json=body, impersonate="chrome", timeout=300)
    return r.status_code, dict(r.headers), r.content.decode("utf-8", "replace")


def _is_cf_block(status, headers, text):
    low = (text or "")[:3000].lower()
    h = {k.lower(): v for k, v in headers.items()}
    return status in (403, 429, 503) and (
        "just a moment" in low or "attention required" in low
        or "cf-mitigated" in h or "cloudflare" in low)


def call(method, url, body=None, sse=False):
    """يرجع (status, headers, text). يجرب httpx ثم curl_cffi لو انحظر من Cloudflare."""
    order = ["curl", "httpx"] if C.PREFER_CURL else ["httpx", "curl"]
    last = (0, {}, "")
    for name in order:
        headers = hdrs(sse)
        log.debug(">>> [%s] %s %s\n    headers=%s\n    body=%s", name, method, url,
                  mask_headers(headers), clip(body) if body is not None else "-")
        t0 = time.time()
        try:
            fn = _t_httpx if name == "httpx" else _t_curl
            status, rh, text = fn(method, url, headers, body)
        except ImportError as e:
            log.warning("transport %s غير متوفر: %s", name, e)
            continue
        except Exception as e:  # noqa
            log.error("transport %s فشل: %r", name, e)
            last = (0, {}, repr(e))
            continue
        log.debug("<<< [%s] HTTP %s (%.2fs)", name, status, time.time() - t0)
        last = (status, rh, text)
        if _is_cf_block(status, rh, text):
            log.warning("Cloudflare حظر الطلب عبر %s -> نجرب الناقل الثاني", name)
            continue
        return last
    return last


def parse_sse(text):
    events, ev, data = [], None, []

    def flush():
        nonlocal ev, data
        if data:
            payload = "\n".join(data)
            try:
                obj = json.loads(payload)
            except json.JSONDecodeError:
                obj = payload
            events.append((ev, obj))
        ev, data = None, []

    for raw in text.splitlines():
        if raw.startswith("event:"):
            ev = raw[6:].strip()
        elif raw.startswith("data:"):
            data.append(raw[5:].lstrip())
        elif not raw.strip():
            flush()
    flush()
    return events


# =====================================================================
#                     استخراج النص من رد السرفر
# =====================================================================
def extract_text(msg):
    if not isinstance(msg, dict):
        return ""
    parts = []
    for b in msg.get("blocks") or []:
        wb = b.get("workflow_block")
        if wb:
            for step in wb.get("steps") or []:
                for it in step.get("items") or []:
                    tp = (it.get("payload") or {}).get("text_payload")
                    if tp and it.get("variant", "answer") == "answer":
                        t = tp.get("text") or "".join(tp.get("chunks") or [])
                        if t:
                            parts.append(t)
    if parts:
        return "\n\n".join(parts).strip()
    for b in msg.get("blocks") or []:
        mb = b.get("markdown_block")
        if mb:
            t = mb.get("answer") or "".join(mb.get("chunks") or [])
            if t:
                parts.append(t)
    if parts:
        return "\n\n".join(parts).strip()
    for k in ("answer", "text"):
        if isinstance(msg.get(k), str) and msg[k].strip():
            return msg[k].strip()
    return ""


MEDIA_URL_RE = re.compile(
    r'https?://[^\s"\\<>]+?\.(?:png|jpe?g|webp|gif|mp4|mov|webm)(?:\?[^\s"\\<>]*)?', re.I)


def new_thread():
    return {"fe_ctx": str(uuid.uuid4()), "last_backend": None,
            "context_uuid": None, "rw_token": None, "n": 0}


def clean_thread(t):
    """حالة المحادثة تأتي من المتصفح — نقبل فقط الحقول المعروفة."""
    base = new_thread()
    if isinstance(t, dict):
        for k in ("fe_ctx", "last_backend", "context_uuid", "rw_token"):
            v = t.get(k)
            if isinstance(v, str) and 0 < len(v) < 2000:
                base[k] = v
        if isinstance(t.get("n"), int):
            base["n"] = t["n"]
    return base


def build_params(query, model, mode, thread):
    followup = bool(thread.get("last_backend"))
    params = {
        "source": "android",
        "version": "2.17",
        "frontend_uuid": str(uuid.uuid4()),
        "frontend_context_uuid": thread["fe_ctx"],
        "user_nextauth_id": C.USER_ID,
        "android_device_id": C.DEVICE_ID,
        "mode": mode,
        "is_related_query": False,
        "is_voice_to_voice": False,
        "timezone": C.TIMEZONE,
        "language": C.LANGUAGE,
        "query_source": "followup" if followup else (
            "computer" if mode == "asi" else "home"),
        "is_incognito": False,
        "use_schematized_api": True,
        "send_back_text_in_streaming_api": False,
        "supported_block_use_cases": C.SUPPORTED_BLOCKS,
        "disable_widgets": ["shopping"],
        "sources": ["web"],
        "model_preference": model,
    }
    if C.USE_ANDROID_PARAMS:
        params["android_assistant_params"] = {
            "supports_android_connectors": False,
            "enabled_android_connectors": {},
            "apps": "[Perplexity, Telegram, Chrome]",
            "client_capabilities": [],
            "version": "2.4",
            "client_type": "thread",
            "camera_input": False,
            "drawing_input": False,
            "is_default_assistant": False,
            "can_read_screen_context": False,
            "is_samsung_preload": False,
            "is_multi_window": False,
            "is_24_hour_format": True,
            "default_sms_app": "com.android.mms",
        }
    if followup:
        params["last_backend_uuid"] = thread["last_backend"]
        if thread.get("rw_token"):
            params["read_write_token"] = thread["rw_token"]
    return params


def ask_once(query, model, mode, thread):
    res = {"ok": False, "text": "", "display_model": None, "urls": [],
           "error": None, "status": 0}
    body = {"query_str": query, "params": build_params(query, model, mode, thread)}
    status, rh, text = call("POST", f"{C.BASE}/rest/sse/perplexity_ask", body, sse=True)
    res["status"] = status
    if status != 200:
        res["error"] = f"HTTP {status}: {clip(text, 500)}"
        log.error("ask فشل: %s", res["error"])
        return res

    events = parse_sse(text)
    log.debug("استلمنا %d event من السرفر", len(events))
    msgs = []
    for i, (ev, obj) in enumerate(events):
        if isinstance(obj, dict):
            log.debug("  [%d] event=%s status=%s final=%s display_model=%s",
                      i, ev, obj.get("status"), obj.get("final"), obj.get("display_model"))
            if ev in (None, "message"):
                msgs.append(obj)
            if ev == "error":
                res["error"] = clip(obj, 500)
    if not msgs:
        res["error"] = res["error"] or "ما وصل أي رد من السرفر"
        log.error("%s | raw=%s", res["error"], clip(text, 1500))
        return res

    final = next((m for m in reversed(msgs) if m.get("final_sse_message")), msgs[-1])
    answer = ""
    for cand in [final] + list(reversed(msgs)):
        answer = extract_text(cand)
        if answer:
            break
    res["text"] = answer
    res["display_model"] = final.get("display_model")
    res["urls"] = list(dict.fromkeys(
        MEDIA_URL_RE.findall(json.dumps(final, ensure_ascii=False))))[:6]

    if not answer and not res["urls"]:
        res["error"] = f"الرد فارغ (status={final.get('status')})"
        log.error("%s", res["error"])
        return res

    res["ok"] = True
    thread["last_backend"] = final.get("backend_uuid") or thread.get("last_backend")
    thread["context_uuid"] = final.get("context_uuid") or thread.get("context_uuid")
    thread["rw_token"] = final.get("read_write_token") or thread.get("rw_token")
    thread["n"] = thread.get("n", 0) + 1
    log.info("رد ناجح | model=%s display=%s chars=%d", model, res["display_model"], len(answer))
    return res


def delete_thread_sync(context_uuid, rw_token):
    body = {"context_uuids": [context_uuid], "entry_uuids": [], "read_write_token": rw_token}
    status, _, text = call("DELETE", f"{C.BASE}/rest/thread", body)
    ok = status in (200, 202, 204)
    log.info("حذف محادثة %s -> HTTP %s", context_uuid, status)
    return ok


MOCK_ANSWER = """## وضع تجريبي

هذا رد وهمي من **DZ T AI** لاختبار الواجهة بدون الاتصال بالـ API.

- يدعم القوائم والخط العريض و`الكود المضمّن`
- ويدعم الجداول وكتل الكود

| النموذج | المزود |
|---|---|
| GPT-6.1 Sol Thinking | OpenAI |
| Claude Sonnet 5.5 Thinking | Anthropic |

```python
def hello(name):
    return f"مرحباً {name}"
```

> سؤالك كان: {q}
"""


def run_chat(query, model_key, thread):
    """ينفّذ الطلب (متزامن) ويرجع dict جاهز للإرسال للمتصفح."""
    thread = clean_thread(thread)
    if MOCK:
        time.sleep(2.0)
        thread["last_backend"] = thread["last_backend"] or str(uuid.uuid4())
        thread["context_uuid"] = thread["context_uuid"] or str(uuid.uuid4())
        thread["rw_token"] = thread["rw_token"] or "mock"
        thread["n"] += 1
        return {"type": "done", "text": MOCK_ANSWER.replace("{q}", query[:200]),
                "thread": thread, "urls": [], "restarted": False}

    mode = MODEL_BY_KEY[model_key]["mode"]
    restarted = False
    res = ask_once(query, model_key, mode, thread)
    if not res["ok"] and thread.get("last_backend"):
        log.warning("المتابعة فشلت -> نعيد المحاولة كمحادثة جديدة")
        thread = new_thread()
        restarted = True
        res = ask_once(query, model_key, mode, thread)
    if not res["ok"]:
        code = res.get("status") or 0
        msg = ("تعذّر الحصول على رد من النموذج"
               + (f" (رمز {code})" if code else "") + ". حاول مرة أخرى.")
        return {"type": "error", "message": msg}
    return {"type": "done", "text": res["text"], "thread": thread,
            "urls": res["urls"], "restarted": restarted,
            "display_model": res.get("display_model")}


# =====================================================================
#                     حد الطلبات (بسيط، في الذاكرة)
# =====================================================================
_hits = defaultdict(deque)
_hits_lock = threading.Lock()


def rate_ok(ip):
    if RATE <= 0:
        return True
    now = time.time()
    with _hits_lock:
        q = _hits[ip]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= RATE:
            return False
        q.append(now)
        if len(_hits) > 5000:  # تنظيف دوري
            for k in [k for k, v in _hits.items() if not v or now - v[-1] > 60]:
                _hits.pop(k, None)
        return True


# =====================================================================
#                              خادم HTTP
# =====================================================================
class Handler(BaseHTTPRequestHandler):
    server_version = "DZTAI/1.0"

    def log_message(self, fmt, *args):  # نستعمل لوجنا
        if DEBUG:
            log.debug("%s - %s", self.address_string(), fmt % args)

    # ---------- أدوات ----------
    def client_ip(self):
        if TRUST_PROXY:
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                return xff.split(",")[0].strip()
        return self.client_address[0]

    def send_json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > 2_000_000:
            return None
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:  # noqa
            return None

    # ---------- GET ----------
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/models":
            return self.send_json({
                "default": C.DEFAULT_MODEL,
                "models": [{"key": m["key"], "label": m["label"], "provider": m["provider"]}
                           for m in C.MODELS]})
        if path == "/api/health":
            return self.send_json({"ok": True, "mock": MOCK})
        return self.serve_static(path)

    def serve_static(self, path):
        rel = unquote(path).lstrip("/") or "index.html"
        target = (STATIC / rel).resolve()
        try:
            target.relative_to(STATIC)
        except ValueError:
            return self.send_error(403)
        if target.is_dir():
            target = target / "index.html"
        if not target.is_file():
            return self.send_error(404)
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
            ctype += "; charset=utf-8"
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        long_cache = target.suffix in (".woff2", ".png", ".ico")
        self.send_header("Cache-Control", "public, max-age=604800" if long_cache else "no-cache")
        self.end_headers()
        self.wfile.write(data)

    # ---------- POST ----------
    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/chat":
            return self.api_chat()
        if path == "/api/delete":
            return self.api_delete()
        self.send_error(404)

    def api_chat(self):
        body = self.read_json()
        if not isinstance(body, dict):
            return self.send_json({"type": "error", "message": "طلب غير صالح"}, 400)
        query = body.get("query")
        model = body.get("model") or C.DEFAULT_MODEL
        if not isinstance(query, str) or not query.strip():
            return self.send_json({"type": "error", "message": "الرسالة فارغة"}, 400)
        if len(query) > MAX_QUERY:
            return self.send_json({"type": "error", "message": "الرسالة طويلة جداً"}, 400)
        if model not in MODEL_BY_KEY:
            return self.send_json({"type": "error", "message": "النموذج غير متاح"}, 400)
        if not rate_ok(self.client_ip()):
            return self.send_json(
                {"type": "error", "message": "طلبات كثيرة، انتظر قليلاً ثم حاول مرة أخرى."}, 429)

        log.info("طلب جديد | model=%s chars=%d ip=%s", model, len(query), self.client_ip())

        # بث SSE: نرسل ping كل 10 ثوان حتى لا ينقطع الاتصال أثناء تفكير النموذج
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Connection", "close")
        self.end_headers()

        box = {}
        done = threading.Event()

        def work():
            try:
                box["r"] = run_chat(query, model, body.get("thread"))
            except Exception:  # noqa
                log.exception("خطأ داخلي أثناء المعالجة")
                box["r"] = {"type": "error", "message": "حدث خطأ داخلي في الخادم."}
            finally:
                done.set()

        threading.Thread(target=work, daemon=True).start()
        try:
            self.wfile.write(b": start\n\n")
            self.wfile.flush()
            while not done.wait(10):
                self.wfile.write(b": ping\n\n")
                self.wfile.flush()
            payload = json.dumps(box["r"], ensure_ascii=False)
            self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            log.info("المتصفح أغلق الاتصال قبل اكتمال الرد")

    def api_delete(self):
        body = self.read_json()
        if not isinstance(body, dict):
            return self.send_json({"ok": False}, 400)
        ctx, tok = body.get("context_uuid"), body.get("rw_token")
        if not (isinstance(ctx, str) and isinstance(tok, str) and ctx and tok):
            return self.send_json({"ok": False}, 400)
        if MOCK:
            return self.send_json({"ok": True})
        try:
            ok = delete_thread_sync(ctx, tok)
        except Exception:  # noqa
            log.exception("فشل حذف المحادثة")
            ok = False
        self.send_json({"ok": ok})


def main():
    setup_logging()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    srv.daemon_threads = True
    log.info("DZ T AI يعمل على http://%s:%d %s", HOST, PORT, "(وضع تجريبي)" if MOCK else "")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("إيقاف الخادم")


if __name__ == "__main__":
    main()
